# 1 "SARD/000/067/251/CWE121_Stack_Based_Buffer_Overflow__src_char_declare_cpy_74b.cpp"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 380 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "SARD/000/067/251/CWE121_Stack_Based_Buffer_Overflow__src_char_declare_cpy_74b.cpp" 2
# 22 "SARD/000/067/251/CWE121_Stack_Based_Buffer_Overflow__src_char_declare_cpy_74b.cpp"
using namespace std;

namespace CWE121_Stack_Based_Buffer_Overflow__src_char_declare_cpy_74
{



void badSink(map<int, char *> dataMap)
{

    char * data = dataMap[2];
    {
        char dest[50] = "";

        strcpy(dest, data);
        printLine(data);
    }
}
# 59 "SARD/000/067/251/CWE121_Stack_Based_Buffer_Overflow__src_char_declare_cpy_74b.cpp"
}
