# 1 "SARD/000/067/840/CWE122_Heap_Based_Buffer_Overflow__cpp_CWE193_char_cpy_54e.cpp"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 380 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "SARD/000/067/840/CWE122_Heap_Based_Buffer_Overflow__cpp_CWE193_char_cpy_54e.cpp" 2
# 26 "SARD/000/067/840/CWE122_Heap_Based_Buffer_Overflow__cpp_CWE193_char_cpy_54e.cpp"
namespace CWE122_Heap_Based_Buffer_Overflow__cpp_CWE193_char_cpy_54
{





void badSink_e(char * data)
{
    {
        char source[10+1] = "AAAAAAAAAA";

        strcpy(data, source);
        printLine(data);
        delete [] data;
    }
}
# 62 "SARD/000/067/840/CWE122_Heap_Based_Buffer_Overflow__cpp_CWE193_char_cpy_54e.cpp"
}
