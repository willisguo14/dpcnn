# 1 "SARD/000/067/427/CWE121_Stack_Based_Buffer_Overflow__src_wchar_t_declare_cpy_44.c"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 367 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "SARD/000/067/427/CWE121_Stack_Based_Buffer_Overflow__src_wchar_t_declare_cpy_44.c" 2
# 23 "SARD/000/067/427/CWE121_Stack_Based_Buffer_Overflow__src_wchar_t_declare_cpy_44.c"
static void badSink(wchar_t * data)
{
    {
        wchar_t dest[50] = L"";

        wcscpy(dest, data);
        printWLine(data);
    }
}

void CWE121_Stack_Based_Buffer_Overflow__src_wchar_t_declare_cpy_44_bad()
{
    wchar_t * data;

    void (*funcPtr) (wchar_t *) = badSink;
    wchar_t dataBuffer[100];
    data = dataBuffer;

    wmemset(data, L'A', 100-1);
    data[100-1] = L'\0';

    funcPtr(data);
}
