# 1 "SARD/000/067/427/CWE121_Stack_Based_Buffer_Overflow__src_wchar_t_declare_cpy_44.c"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 367 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "SARD/000/067/427/CWE121_Stack_Based_Buffer_Overflow__src_wchar_t_declare_cpy_44.c" 2
# 52 "SARD/000/067/427/CWE121_Stack_Based_Buffer_Overflow__src_wchar_t_declare_cpy_44.c"
static void goodG2BSink(wchar_t * data)
{
    {
        wchar_t dest[50] = L"";

        wcscpy(dest, data);
        printWLine(data);
    }
}

static void goodG2B()
{
    wchar_t * data;
    void (*funcPtr) (wchar_t *) = goodG2BSink;
    wchar_t dataBuffer[100];
    data = dataBuffer;

    wmemset(data, L'A', 50-1);
    data[50-1] = L'\0';
    funcPtr(data);
}

void CWE121_Stack_Based_Buffer_Overflow__src_wchar_t_declare_cpy_44_good()
{
    goodG2B();
}
