# 1 "SARD/000/067/029/CWE121_Stack_Based_Buffer_Overflow__placement_new_declare_06.cpp"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 380 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "SARD/000/067/029/CWE121_Stack_Based_Buffer_Overflow__placement_new_declare_06.cpp" 2
# 23 "SARD/000/067/029/CWE121_Stack_Based_Buffer_Overflow__placement_new_declare_06.cpp"
static const int STATIC_CONST_FIVE = 5;

namespace CWE121_Stack_Based_Buffer_Overflow__placement_new_declare_06
{



void bad()
{
    char * data;
    char dataBadBuffer[sizeof(OneIntClass)];
    char dataGoodBuffer[sizeof(TwoIntsClass)];
    if(STATIC_CONST_FIVE==5)
    {

        data = dataBadBuffer;
    }
    if(STATIC_CONST_FIVE==5)
    {
        {





            TwoIntsClass * classTwo = new(data) TwoIntsClass;

            classTwo->intOne = 5;
            classTwo->intTwo = 10;
            printIntLine(classTwo->intOne);

        }
    }
}
# 194 "SARD/000/067/029/CWE121_Stack_Based_Buffer_Overflow__placement_new_declare_06.cpp"
}
