# 1 "SARD/000/067/029/CWE121_Stack_Based_Buffer_Overflow__placement_new_declare_06.cpp"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 380 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "SARD/000/067/029/CWE121_Stack_Based_Buffer_Overflow__placement_new_declare_06.cpp" 2
# 23 "SARD/000/067/029/CWE121_Stack_Based_Buffer_Overflow__placement_new_declare_06.cpp"
static const int STATIC_CONST_FIVE = 5;

namespace CWE121_Stack_Based_Buffer_Overflow__placement_new_declare_06
{
# 63 "SARD/000/067/029/CWE121_Stack_Based_Buffer_Overflow__placement_new_declare_06.cpp"
static void goodB2G1()
{
    char * data;
    char dataBadBuffer[sizeof(OneIntClass)];
    char dataGoodBuffer[sizeof(TwoIntsClass)];
    if(STATIC_CONST_FIVE==5)
    {

        data = dataBadBuffer;
    }
    if(STATIC_CONST_FIVE!=5)
    {

        printLine("Benign, fixed string");
    }
    else
    {
        {





            OneIntClass * classOne = new(data) OneIntClass;

            classOne->intOne = 5;
            printIntLine(classOne->intOne);
        }
    }
}


static void goodB2G2()
{
    char * data;
    char dataBadBuffer[sizeof(OneIntClass)];
    char dataGoodBuffer[sizeof(TwoIntsClass)];
    if(STATIC_CONST_FIVE==5)
    {

        data = dataBadBuffer;
    }
    if(STATIC_CONST_FIVE==5)
    {
        {





            OneIntClass * classOne = new(data) OneIntClass;

            classOne->intOne = 5;
            printIntLine(classOne->intOne);
        }
    }
}


static void goodG2B1()
{
    char * data;
    char dataBadBuffer[sizeof(OneIntClass)];
    char dataGoodBuffer[sizeof(TwoIntsClass)];
    if(STATIC_CONST_FIVE!=5)
    {

        printLine("Benign, fixed string");
    }
    else
    {

        data = dataGoodBuffer;
    }
    if(STATIC_CONST_FIVE==5)
    {
        {





            TwoIntsClass * classTwo = new(data) TwoIntsClass;

            classTwo->intOne = 5;
            classTwo->intTwo = 10;
            printIntLine(classTwo->intOne);

        }
    }
}


static void goodG2B2()
{
    char * data;
    char dataBadBuffer[sizeof(OneIntClass)];
    char dataGoodBuffer[sizeof(TwoIntsClass)];
    if(STATIC_CONST_FIVE==5)
    {

        data = dataGoodBuffer;
    }
    if(STATIC_CONST_FIVE==5)
    {
        {





            TwoIntsClass * classTwo = new(data) TwoIntsClass;

            classTwo->intOne = 5;
            classTwo->intTwo = 10;
            printIntLine(classTwo->intOne);

        }
    }
}

void good()
{
    goodB2G1();
    goodB2G2();
    goodG2B1();
    goodG2B2();
}



}
