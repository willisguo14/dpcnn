# 1 "SARD/000/067/019/CWE121_Stack_Based_Buffer_Overflow__placement_new_alloca_72b.cpp"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 380 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "SARD/000/067/019/CWE121_Stack_Based_Buffer_Overflow__placement_new_alloca_72b.cpp" 2
# 21 "SARD/000/067/019/CWE121_Stack_Based_Buffer_Overflow__placement_new_alloca_72b.cpp"
using namespace std;

namespace CWE121_Stack_Based_Buffer_Overflow__placement_new_alloca_72
{



void badSink(vector<char *> dataVector)
{

    char * data = dataVector[2];
    {





        TwoIntsClass * classTwo = new(data) TwoIntsClass;

        classTwo->intOne = 5;
        classTwo->intTwo = 10;
        printIntLine(classTwo->intOne);

    }
}
# 89 "SARD/000/067/019/CWE121_Stack_Based_Buffer_Overflow__placement_new_alloca_72b.cpp"
}
