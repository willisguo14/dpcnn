# 1 "SARD/000/067/541/CWE122_Heap_Based_Buffer_Overflow__cpp_CWE129_connect_socket_32.cpp"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 380 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "SARD/000/067/541/CWE122_Heap_Based_Buffer_Overflow__cpp_CWE129_connect_socket_32.cpp" 2
# 42 "SARD/000/067/541/CWE122_Heap_Based_Buffer_Overflow__cpp_CWE129_connect_socket_32.cpp"
namespace CWE122_Heap_Based_Buffer_Overflow__cpp_CWE129_connect_socket_32
{



void bad()
{
    int data;
    int *dataPtr1 = &data;
    int *dataPtr2 = &data;

    data = -1;
    {
        int data = *dataPtr1;
        {




            int recvResult;
            struct sockaddr_in service;
            int connectSocket = -1;
            char inputBuffer[(3 * sizeof(data) + 2)];
            do
            {
# 75 "SARD/000/067/541/CWE122_Heap_Based_Buffer_Overflow__cpp_CWE129_connect_socket_32.cpp"
                connectSocket = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
                if (connectSocket == -1)
                {
                    break;
                }
                memset(&service, 0, sizeof(service));
                service.sin_family = AF_INET;
                service.sin_addr.s_addr = inet_addr("127.0.0.1");
                service.sin_port = htons(27015);
                if (connect(connectSocket, (struct sockaddr*)&service, sizeof(service)) == -1)
                {
                    break;
                }


                recvResult = recv(connectSocket, inputBuffer, (3 * sizeof(data) + 2) - 1, 0);
                if (recvResult == -1 || recvResult == 0)
                {
                    break;
                }

                inputBuffer[recvResult] = '\0';

                data = atoi(inputBuffer);
            }
            while (0);
            if (connectSocket != -1)
            {
                close(connectSocket);
            }






        }
        *dataPtr1 = data;
    }
    {
        int data = *dataPtr2;
        {
            int i;
            int * buffer = new int[10];

            for (i = 0; i < 10; i++)
            {
                buffer[i] = 0;
            }


            if (data >= 0)
            {
                buffer[data] = 1;

                for(i = 0; i < 10; i++)
                {
                    printIntLine(buffer[i]);
                }
            }
            else
            {
                printLine("ERROR: Array index is negative.");
            }
            delete[] buffer;
        }
    }
}
# 298 "SARD/000/067/541/CWE122_Heap_Based_Buffer_Overflow__cpp_CWE129_connect_socket_32.cpp"
}
