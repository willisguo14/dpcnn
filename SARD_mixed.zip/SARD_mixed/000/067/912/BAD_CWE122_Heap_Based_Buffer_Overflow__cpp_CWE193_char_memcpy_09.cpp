# 1 "SARD/000/067/912/CWE122_Heap_Based_Buffer_Overflow__cpp_CWE193_char_memcpy_09.cpp"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 380 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "SARD/000/067/912/CWE122_Heap_Based_Buffer_Overflow__cpp_CWE193_char_memcpy_09.cpp" 2
# 26 "SARD/000/067/912/CWE122_Heap_Based_Buffer_Overflow__cpp_CWE193_char_memcpy_09.cpp"
namespace CWE122_Heap_Based_Buffer_Overflow__cpp_CWE193_char_memcpy_09
{



void bad()
{
    char * data;
    data = NULL;
    if(GLOBAL_CONST_TRUE)
    {

        data = new char[10];
    }
    {
        char source[10+1] = "AAAAAAAAAA";


        memcpy(data, source, (strlen(source) + 1) * sizeof(char));
        printLine(data);
        delete [] data;
    }
}
# 107 "SARD/000/067/912/CWE122_Heap_Based_Buffer_Overflow__cpp_CWE193_char_memcpy_09.cpp"
}
