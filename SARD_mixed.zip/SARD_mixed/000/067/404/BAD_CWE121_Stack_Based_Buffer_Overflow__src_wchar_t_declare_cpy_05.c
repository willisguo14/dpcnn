# 1 "SARD/000/067/404/CWE121_Stack_Based_Buffer_Overflow__src_wchar_t_declare_cpy_05.c"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 367 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "SARD/000/067/404/CWE121_Stack_Based_Buffer_Overflow__src_wchar_t_declare_cpy_05.c" 2
# 25 "SARD/000/067/404/CWE121_Stack_Based_Buffer_Overflow__src_wchar_t_declare_cpy_05.c"
static int staticTrue = 1;
static int staticFalse = 0;



void CWE121_Stack_Based_Buffer_Overflow__src_wchar_t_declare_cpy_05_bad()
{
    wchar_t * data;
    wchar_t dataBuffer[100];
    data = dataBuffer;
    if(staticTrue)
    {

        wmemset(data, L'A', 100-1);
        data[100-1] = L'\0';
    }
    {
        wchar_t dest[50] = L"";

        wcscpy(dest, data);
        printWLine(data);
    }
}
