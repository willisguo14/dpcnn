# 1 "SARD/000/067/263/CWE121_Stack_Based_Buffer_Overflow__src_wchar_t_alloca_cat_08.c"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 367 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "SARD/000/067/263/CWE121_Stack_Based_Buffer_Overflow__src_wchar_t_alloca_cat_08.c" 2
# 25 "SARD/000/067/263/CWE121_Stack_Based_Buffer_Overflow__src_wchar_t_alloca_cat_08.c"
static int staticReturnsTrue()
{
    return 1;
}

static int staticReturnsFalse()
{
    return 0;
}



void CWE121_Stack_Based_Buffer_Overflow__src_wchar_t_alloca_cat_08_bad()
{
    wchar_t * data;
    wchar_t * dataBuffer = (wchar_t *)ALLOCA(100*sizeof(wchar_t));
    data = dataBuffer;
    if(staticReturnsTrue())
    {

        wmemset(data, L'A', 100-1);
        data[100-1] = L'\0';
    }
    {
        wchar_t dest[50] = L"";

        wcscat(dest, data);
        printWLine(data);
    }
}
