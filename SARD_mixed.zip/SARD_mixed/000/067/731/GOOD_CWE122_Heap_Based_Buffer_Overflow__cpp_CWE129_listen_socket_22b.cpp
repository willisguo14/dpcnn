# 1 "SARD/000/067/731/CWE122_Heap_Based_Buffer_Overflow__cpp_CWE129_listen_socket_22b.cpp"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 380 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "SARD/000/067/731/CWE122_Heap_Based_Buffer_Overflow__cpp_CWE129_listen_socket_22b.cpp" 2
# 20 "SARD/000/067/731/CWE122_Heap_Based_Buffer_Overflow__cpp_CWE129_listen_socket_22b.cpp"
namespace CWE122_Heap_Based_Buffer_Overflow__cpp_CWE129_listen_socket_22
{
# 67 "SARD/000/067/731/CWE122_Heap_Based_Buffer_Overflow__cpp_CWE129_listen_socket_22b.cpp"
extern int goodB2G1Global;
extern int goodB2G2Global;
extern int goodG2B1Global;


void goodB2G1Sink(int data)
{
    if(goodB2G1Global)
    {

        printLine("Benign, fixed string");
    }
    else
    {
        {
            int i;
            int * buffer = new int[10];

            for (i = 0; i < 10; i++)
            {
                buffer[i] = 0;
            }

            if (data >= 0 && data < (10))
            {
                buffer[data] = 1;

                for(i = 0; i < 10; i++)
                {
                    printIntLine(buffer[i]);
                }
            }
            else
            {
                printLine("ERROR: Array index is out-of-bounds");
            }
            delete[] buffer;
        }
    }
}


void goodB2G2Sink(int data)
{
    if(goodB2G2Global)
    {
        {
            int i;
            int * buffer = new int[10];

            for (i = 0; i < 10; i++)
            {
                buffer[i] = 0;
            }

            if (data >= 0 && data < (10))
            {
                buffer[data] = 1;

                for(i = 0; i < 10; i++)
                {
                    printIntLine(buffer[i]);
                }
            }
            else
            {
                printLine("ERROR: Array index is out-of-bounds");
            }
            delete[] buffer;
        }
    }
}


void goodG2B1Sink(int data)
{
    if(goodG2B1Global)
    {
        {
            int i;
            int * buffer = new int[10];

            for (i = 0; i < 10; i++)
            {
                buffer[i] = 0;
            }


            if (data >= 0)
            {
                buffer[data] = 1;

                for(i = 0; i < 10; i++)
                {
                    printIntLine(buffer[i]);
                }
            }
            else
            {
                printLine("ERROR: Array index is negative.");
            }
            delete[] buffer;
        }
    }
}



}
