# 1 "SARD/000/067/990/CWE122_Heap_Based_Buffer_Overflow__cpp_CWE193_char_memmove_66b.cpp"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 380 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "SARD/000/067/990/CWE122_Heap_Based_Buffer_Overflow__cpp_CWE193_char_memmove_66b.cpp" 2
# 26 "SARD/000/067/990/CWE122_Heap_Based_Buffer_Overflow__cpp_CWE193_char_memmove_66b.cpp"
namespace CWE122_Heap_Based_Buffer_Overflow__cpp_CWE193_char_memmove_66
{



void badSink(char * dataArray[])
{

    char * data = dataArray[2];
    {
        char source[10+1] = "AAAAAAAAAA";


        memmove(data, source, (strlen(source) + 1) * sizeof(char));
        printLine(data);
        delete [] data;
    }
}
# 65 "SARD/000/067/990/CWE122_Heap_Based_Buffer_Overflow__cpp_CWE193_char_memmove_66b.cpp"
}
