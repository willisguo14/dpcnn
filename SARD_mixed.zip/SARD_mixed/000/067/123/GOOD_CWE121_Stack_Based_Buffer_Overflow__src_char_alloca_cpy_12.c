# 1 "SARD/000/067/123/CWE121_Stack_Based_Buffer_Overflow__src_char_alloca_cpy_12.c"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 367 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "SARD/000/067/123/CWE121_Stack_Based_Buffer_Overflow__src_char_alloca_cpy_12.c" 2
# 54 "SARD/000/067/123/CWE121_Stack_Based_Buffer_Overflow__src_char_alloca_cpy_12.c"
static void goodG2B()
{
    char * data;
    char * dataBuffer = (char *)ALLOCA(100*sizeof(char));
    data = dataBuffer;
    if(globalReturnsTrueOrFalse())
    {

        memset(data, 'A', 50-1);
        data[50-1] = '\0';
    }
    else
    {

        memset(data, 'A', 50-1);
        data[50-1] = '\0';
    }
    {
        char dest[50] = "";

        strcpy(dest, data);
        printLine(data);
    }
}

void CWE121_Stack_Based_Buffer_Overflow__src_char_alloca_cpy_12_good()
{
    goodG2B();
}
