# 1 "SARD/000/067/048/CWE121_Stack_Based_Buffer_Overflow__placement_new_declare_45.cpp"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 380 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "SARD/000/067/048/CWE121_Stack_Based_Buffer_Overflow__placement_new_declare_45.cpp" 2
# 20 "SARD/000/067/048/CWE121_Stack_Based_Buffer_Overflow__placement_new_declare_45.cpp"
namespace CWE121_Stack_Based_Buffer_Overflow__placement_new_declare_45
{

static char * badData;
static char * goodG2BData;
static char * goodB2GData;
# 63 "SARD/000/067/048/CWE121_Stack_Based_Buffer_Overflow__placement_new_declare_45.cpp"
static void goodG2BSink()
{
    char * data = goodG2BData;
    {





        TwoIntsClass * classTwo = new(data) TwoIntsClass;

        classTwo->intOne = 5;
        classTwo->intTwo = 10;
        printIntLine(classTwo->intOne);

    }
}

static void goodG2B()
{
    char * data;
    char dataBadBuffer[sizeof(OneIntClass)];
    char dataGoodBuffer[sizeof(TwoIntsClass)];

    data = dataGoodBuffer;
    goodG2BData = data;
    goodG2BSink();
}


static void goodB2GSink()
{
    char * data = goodB2GData;
    {





        OneIntClass * classOne = new(data) OneIntClass;

        classOne->intOne = 5;
        printIntLine(classOne->intOne);
    }
}

static void goodB2G()
{
    char * data;
    char dataBadBuffer[sizeof(OneIntClass)];
    char dataGoodBuffer[sizeof(TwoIntsClass)];

    data = dataBadBuffer;
    goodB2GData = data;
    goodB2GSink();
}

void good()
{
    goodG2B();
    goodB2G();
}



}
