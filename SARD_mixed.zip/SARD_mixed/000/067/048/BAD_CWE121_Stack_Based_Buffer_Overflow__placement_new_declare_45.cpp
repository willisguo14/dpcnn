# 1 "SARD/000/067/048/CWE121_Stack_Based_Buffer_Overflow__placement_new_declare_45.cpp"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 380 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "SARD/000/067/048/CWE121_Stack_Based_Buffer_Overflow__placement_new_declare_45.cpp" 2
# 20 "SARD/000/067/048/CWE121_Stack_Based_Buffer_Overflow__placement_new_declare_45.cpp"
namespace CWE121_Stack_Based_Buffer_Overflow__placement_new_declare_45
{

static char * badData;
static char * goodG2BData;
static char * goodB2GData;



static void badSink()
{
    char * data = badData;
    {





        TwoIntsClass * classTwo = new(data) TwoIntsClass;

        classTwo->intOne = 5;
        classTwo->intTwo = 10;
        printIntLine(classTwo->intOne);

    }
}

void bad()
{
    char * data;
    char dataBadBuffer[sizeof(OneIntClass)];
    char dataGoodBuffer[sizeof(TwoIntsClass)];

    data = dataBadBuffer;
    badData = data;
    badSink();
}
# 128 "SARD/000/067/048/CWE121_Stack_Based_Buffer_Overflow__placement_new_declare_45.cpp"
}
