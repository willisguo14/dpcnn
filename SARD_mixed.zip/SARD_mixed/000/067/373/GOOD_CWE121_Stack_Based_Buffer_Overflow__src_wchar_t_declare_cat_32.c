# 1 "SARD/000/067/373/CWE121_Stack_Based_Buffer_Overflow__src_wchar_t_declare_cat_32.c"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 367 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "SARD/000/067/373/CWE121_Stack_Based_Buffer_Overflow__src_wchar_t_declare_cat_32.c" 2
# 53 "SARD/000/067/373/CWE121_Stack_Based_Buffer_Overflow__src_wchar_t_declare_cat_32.c"
static void goodG2B()
{
    wchar_t * data;
    wchar_t * *dataPtr1 = &data;
    wchar_t * *dataPtr2 = &data;
    wchar_t dataBuffer[100];
    data = dataBuffer;
    {
        wchar_t * data = *dataPtr1;

        wmemset(data, L'A', 50-1);
        data[50-1] = L'\0';
        *dataPtr1 = data;
    }
    {
        wchar_t * data = *dataPtr2;
        {
            wchar_t dest[50] = L"";

            wcscat(dest, data);
            printWLine(data);
        }
    }
}

void CWE121_Stack_Based_Buffer_Overflow__src_wchar_t_declare_cat_32_good()
{
    goodG2B();
}
