# 1 "SARD/000/067/141/CWE121_Stack_Based_Buffer_Overflow__src_char_alloca_cpy_51b.c"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 367 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "SARD/000/067/141/CWE121_Stack_Based_Buffer_Overflow__src_char_alloca_cpy_51b.c" 2
# 40 "SARD/000/067/141/CWE121_Stack_Based_Buffer_Overflow__src_char_alloca_cpy_51b.c"
void CWE121_Stack_Based_Buffer_Overflow__src_char_alloca_cpy_51b_goodG2BSink(char * data)
{
    {
        char dest[50] = "";

        strcpy(dest, data);
        printLine(data);
    }
}
