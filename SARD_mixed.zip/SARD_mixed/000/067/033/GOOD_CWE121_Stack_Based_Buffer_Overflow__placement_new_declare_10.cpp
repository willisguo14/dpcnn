# 1 "SARD/000/067/033/CWE121_Stack_Based_Buffer_Overflow__placement_new_declare_10.cpp"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 380 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "SARD/000/067/033/CWE121_Stack_Based_Buffer_Overflow__placement_new_declare_10.cpp" 2
# 20 "SARD/000/067/033/CWE121_Stack_Based_Buffer_Overflow__placement_new_declare_10.cpp"
namespace CWE121_Stack_Based_Buffer_Overflow__placement_new_declare_10
{
# 58 "SARD/000/067/033/CWE121_Stack_Based_Buffer_Overflow__placement_new_declare_10.cpp"
static void goodB2G1()
{
    char * data;
    char dataBadBuffer[sizeof(OneIntClass)];
    char dataGoodBuffer[sizeof(TwoIntsClass)];
    if(globalTrue)
    {

        data = dataBadBuffer;
    }
    if(globalFalse)
    {

        printLine("Benign, fixed string");
    }
    else
    {
        {





            OneIntClass * classOne = new(data) OneIntClass;

            classOne->intOne = 5;
            printIntLine(classOne->intOne);
        }
    }
}


static void goodB2G2()
{
    char * data;
    char dataBadBuffer[sizeof(OneIntClass)];
    char dataGoodBuffer[sizeof(TwoIntsClass)];
    if(globalTrue)
    {

        data = dataBadBuffer;
    }
    if(globalTrue)
    {
        {





            OneIntClass * classOne = new(data) OneIntClass;

            classOne->intOne = 5;
            printIntLine(classOne->intOne);
        }
    }
}


static void goodG2B1()
{
    char * data;
    char dataBadBuffer[sizeof(OneIntClass)];
    char dataGoodBuffer[sizeof(TwoIntsClass)];
    if(globalFalse)
    {

        printLine("Benign, fixed string");
    }
    else
    {

        data = dataGoodBuffer;
    }
    if(globalTrue)
    {
        {





            TwoIntsClass * classTwo = new(data) TwoIntsClass;

            classTwo->intOne = 5;
            classTwo->intTwo = 10;
            printIntLine(classTwo->intOne);

        }
    }
}


static void goodG2B2()
{
    char * data;
    char dataBadBuffer[sizeof(OneIntClass)];
    char dataGoodBuffer[sizeof(TwoIntsClass)];
    if(globalTrue)
    {

        data = dataGoodBuffer;
    }
    if(globalTrue)
    {
        {





            TwoIntsClass * classTwo = new(data) TwoIntsClass;

            classTwo->intOne = 5;
            classTwo->intTwo = 10;
            printIntLine(classTwo->intOne);

        }
    }
}

void good()
{
    goodB2G1();
    goodB2G2();
    goodG2B1();
    goodG2B2();
}



}
