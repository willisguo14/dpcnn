# 1 "SARD/000/067/033/CWE121_Stack_Based_Buffer_Overflow__placement_new_declare_10.cpp"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 380 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "SARD/000/067/033/CWE121_Stack_Based_Buffer_Overflow__placement_new_declare_10.cpp" 2
# 20 "SARD/000/067/033/CWE121_Stack_Based_Buffer_Overflow__placement_new_declare_10.cpp"
namespace CWE121_Stack_Based_Buffer_Overflow__placement_new_declare_10
{



void bad()
{
    char * data;
    char dataBadBuffer[sizeof(OneIntClass)];
    char dataGoodBuffer[sizeof(TwoIntsClass)];
    if(globalTrue)
    {

        data = dataBadBuffer;
    }
    if(globalTrue)
    {
        {





            TwoIntsClass * classTwo = new(data) TwoIntsClass;

            classTwo->intOne = 5;
            classTwo->intTwo = 10;
            printIntLine(classTwo->intOne);

        }
    }
}
# 189 "SARD/000/067/033/CWE121_Stack_Based_Buffer_Overflow__placement_new_declare_10.cpp"
}
