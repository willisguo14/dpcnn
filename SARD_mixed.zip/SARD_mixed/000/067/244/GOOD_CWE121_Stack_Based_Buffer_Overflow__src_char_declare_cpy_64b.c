# 1 "SARD/000/067/244/CWE121_Stack_Based_Buffer_Overflow__src_char_declare_cpy_64b.c"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 367 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "SARD/000/067/244/CWE121_Stack_Based_Buffer_Overflow__src_char_declare_cpy_64b.c" 2
# 42 "SARD/000/067/244/CWE121_Stack_Based_Buffer_Overflow__src_char_declare_cpy_64b.c"
void CWE121_Stack_Based_Buffer_Overflow__src_char_declare_cpy_64b_goodG2BSink(void * dataVoidPtr)
{

    char * * dataPtr = (char * *)dataVoidPtr;

    char * data = (*dataPtr);
    {
        char dest[50] = "";

        strcpy(dest, data);
        printLine(data);
    }
}
