# 1 "SARD/000/067/450/CWE121_Stack_Based_Buffer_Overflow__wchar_t_type_overrun_memcpy_03.c"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 367 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "SARD/000/067/450/CWE121_Stack_Based_Buffer_Overflow__wchar_t_type_overrun_memcpy_03.c" 2
# 25 "SARD/000/067/450/CWE121_Stack_Based_Buffer_Overflow__wchar_t_type_overrun_memcpy_03.c"
typedef struct _charVoid
{
    wchar_t charFirst[16];
    void * voidSecond;
    void * voidThird;
} charVoid;
# 57 "SARD/000/067/450/CWE121_Stack_Based_Buffer_Overflow__wchar_t_type_overrun_memcpy_03.c"
static void good1()
{
    if(5!=5)
    {

        printLine("Benign, fixed string");
    }
    else
    {
        {
            charVoid structCharVoid;
            structCharVoid.voidSecond = (void *)L"0123456789abcde0123";

            printWLine((wchar_t *)structCharVoid.voidSecond);

            memcpy(structCharVoid.charFirst, L"0123456789abcde0123", sizeof(structCharVoid.charFirst));
            structCharVoid.charFirst[(sizeof(structCharVoid.charFirst)/sizeof(wchar_t))-1] = L'\0';
            printWLine((wchar_t *)structCharVoid.charFirst);
            printWLine((wchar_t *)structCharVoid.voidSecond);
        }
    }
}


static void good2()
{
    if(5==5)
    {
        {
            charVoid structCharVoid;
            structCharVoid.voidSecond = (void *)L"0123456789abcde0123";

            printWLine((wchar_t *)structCharVoid.voidSecond);

            memcpy(structCharVoid.charFirst, L"0123456789abcde0123", sizeof(structCharVoid.charFirst));
            structCharVoid.charFirst[(sizeof(structCharVoid.charFirst)/sizeof(wchar_t))-1] = L'\0';
            printWLine((wchar_t *)structCharVoid.charFirst);
            printWLine((wchar_t *)structCharVoid.voidSecond);
        }
    }
}

void CWE121_Stack_Based_Buffer_Overflow__wchar_t_type_overrun_memcpy_03_good()
{
    good1();
    good2();
}
