# 1 "SARD/000/067/205/CWE121_Stack_Based_Buffer_Overflow__src_char_declare_cat_82_bad.cpp"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 380 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "SARD/000/067/205/CWE121_Stack_Based_Buffer_Overflow__src_char_declare_cat_82_bad.cpp" 2
# 21 "SARD/000/067/205/CWE121_Stack_Based_Buffer_Overflow__src_char_declare_cat_82_bad.cpp"
namespace CWE121_Stack_Based_Buffer_Overflow__src_char_declare_cat_82
{

void CWE121_Stack_Based_Buffer_Overflow__src_char_declare_cat_82_bad::action(char * data)
{
    {
        char dest[50] = "";

        strcat(dest, data);
        printLine(data);
    }
}

}
