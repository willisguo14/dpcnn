# 1 "SARD/000/067/863/CWE122_Heap_Based_Buffer_Overflow__cpp_CWE193_char_loop_08.cpp"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 380 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "SARD/000/067/863/CWE122_Heap_Based_Buffer_Overflow__cpp_CWE193_char_loop_08.cpp" 2
# 29 "SARD/000/067/863/CWE122_Heap_Based_Buffer_Overflow__cpp_CWE193_char_loop_08.cpp"
static int staticReturnsTrue()
{
    return 1;
}

static int staticReturnsFalse()
{
    return 0;
}

namespace CWE122_Heap_Based_Buffer_Overflow__cpp_CWE193_char_loop_08
{
# 73 "SARD/000/067/863/CWE122_Heap_Based_Buffer_Overflow__cpp_CWE193_char_loop_08.cpp"
static void goodG2B1()
{
    char * data;
    data = NULL;
    if(staticReturnsFalse())
    {

        printLine("Benign, fixed string");
    }
    else
    {

        data = new char[10+1];
    }
    {
        char source[10+1] = "AAAAAAAAAA";
        size_t i, sourceLen;
        sourceLen = strlen(source);


        for (i = 0; i < sourceLen + 1; i++)
        {
            data[i] = source[i];
        }
        printLine(data);
        delete [] data;
    }
}


static void goodG2B2()
{
    char * data;
    data = NULL;
    if(staticReturnsTrue())
    {

        data = new char[10+1];
    }
    {
        char source[10+1] = "AAAAAAAAAA";
        size_t i, sourceLen;
        sourceLen = strlen(source);


        for (i = 0; i < sourceLen + 1; i++)
        {
            data[i] = source[i];
        }
        printLine(data);
        delete [] data;
    }
}

void good()
{
    goodG2B1();
    goodG2B2();
}



}
