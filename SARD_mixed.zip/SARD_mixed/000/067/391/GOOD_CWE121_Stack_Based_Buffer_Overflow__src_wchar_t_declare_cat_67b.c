# 1 "SARD/000/067/391/CWE121_Stack_Based_Buffer_Overflow__src_wchar_t_declare_cat_67b.c"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 367 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "SARD/000/067/391/CWE121_Stack_Based_Buffer_Overflow__src_wchar_t_declare_cat_67b.c" 2
# 21 "SARD/000/067/391/CWE121_Stack_Based_Buffer_Overflow__src_wchar_t_declare_cat_67b.c"
typedef struct _CWE121_Stack_Based_Buffer_Overflow__src_wchar_t_declare_cat_67_structType
{
    wchar_t * structFirst;
} CWE121_Stack_Based_Buffer_Overflow__src_wchar_t_declare_cat_67_structType;
# 44 "SARD/000/067/391/CWE121_Stack_Based_Buffer_Overflow__src_wchar_t_declare_cat_67b.c"
void CWE121_Stack_Based_Buffer_Overflow__src_wchar_t_declare_cat_67b_goodG2BSink(CWE121_Stack_Based_Buffer_Overflow__src_wchar_t_declare_cat_67_structType myStruct)
{
    wchar_t * data = myStruct.structFirst;
    {
        wchar_t dest[50] = L"";

        wcscat(dest, data);
        printWLine(data);
    }
}
