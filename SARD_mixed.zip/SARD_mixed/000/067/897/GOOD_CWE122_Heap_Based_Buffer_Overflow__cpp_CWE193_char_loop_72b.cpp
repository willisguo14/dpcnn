# 1 "SARD/000/067/897/CWE122_Heap_Based_Buffer_Overflow__cpp_CWE193_char_loop_72b.cpp"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 380 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "SARD/000/067/897/CWE122_Heap_Based_Buffer_Overflow__cpp_CWE193_char_loop_72b.cpp" 2
# 27 "SARD/000/067/897/CWE122_Heap_Based_Buffer_Overflow__cpp_CWE193_char_loop_72b.cpp"
using namespace std;

namespace CWE122_Heap_Based_Buffer_Overflow__cpp_CWE193_char_loop_72
{
# 58 "SARD/000/067/897/CWE122_Heap_Based_Buffer_Overflow__cpp_CWE193_char_loop_72b.cpp"
void goodG2BSink(vector<char *> dataVector)
{
    char * data = dataVector[2];
    {
        char source[10+1] = "AAAAAAAAAA";
        size_t i, sourceLen;
        sourceLen = strlen(source);


        for (i = 0; i < sourceLen + 1; i++)
        {
            data[i] = source[i];
        }
        printLine(data);
        delete [] data;
    }
}



}
