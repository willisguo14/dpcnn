# 1 "SARD/000/067/270/CWE121_Stack_Based_Buffer_Overflow__src_wchar_t_alloca_cat_15.c"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 367 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "SARD/000/067/270/CWE121_Stack_Based_Buffer_Overflow__src_wchar_t_alloca_cat_15.c" 2
# 23 "SARD/000/067/270/CWE121_Stack_Based_Buffer_Overflow__src_wchar_t_alloca_cat_15.c"
void CWE121_Stack_Based_Buffer_Overflow__src_wchar_t_alloca_cat_15_bad()
{
    wchar_t * data;
    wchar_t * dataBuffer = (wchar_t *)ALLOCA(100*sizeof(wchar_t));
    data = dataBuffer;
    switch(6)
    {
    case 6:

        wmemset(data, L'A', 100-1);
        data[100-1] = L'\0';
        break;
    default:

        printLine("Benign, fixed string");
        break;
    }
    {
        wchar_t dest[50] = L"";

        wcscat(dest, data);
        printWLine(data);
    }
}
