# 1 "SARD/000/067/270/CWE121_Stack_Based_Buffer_Overflow__src_wchar_t_alloca_cat_15.c"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 367 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "SARD/000/067/270/CWE121_Stack_Based_Buffer_Overflow__src_wchar_t_alloca_cat_15.c" 2
# 53 "SARD/000/067/270/CWE121_Stack_Based_Buffer_Overflow__src_wchar_t_alloca_cat_15.c"
static void goodG2B1()
{
    wchar_t * data;
    wchar_t * dataBuffer = (wchar_t *)ALLOCA(100*sizeof(wchar_t));
    data = dataBuffer;
    switch(5)
    {
    case 6:

        printLine("Benign, fixed string");
        break;
    default:

        wmemset(data, L'A', 50-1);
        data[50-1] = L'\0';
        break;
    }
    {
        wchar_t dest[50] = L"";

        wcscat(dest, data);
        printWLine(data);
    }
}


static void goodG2B2()
{
    wchar_t * data;
    wchar_t * dataBuffer = (wchar_t *)ALLOCA(100*sizeof(wchar_t));
    data = dataBuffer;
    switch(6)
    {
    case 6:

        wmemset(data, L'A', 50-1);
        data[50-1] = L'\0';
        break;
    default:

        printLine("Benign, fixed string");
        break;
    }
    {
        wchar_t dest[50] = L"";

        wcscat(dest, data);
        printWLine(data);
    }
}

void CWE121_Stack_Based_Buffer_Overflow__src_wchar_t_alloca_cat_15_good()
{
    goodG2B1();
    goodG2B2();
}
