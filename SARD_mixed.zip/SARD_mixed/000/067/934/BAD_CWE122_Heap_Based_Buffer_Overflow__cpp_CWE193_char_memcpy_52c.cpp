# 1 "SARD/000/067/934/CWE122_Heap_Based_Buffer_Overflow__cpp_CWE193_char_memcpy_52c.cpp"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 380 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "SARD/000/067/934/CWE122_Heap_Based_Buffer_Overflow__cpp_CWE193_char_memcpy_52c.cpp" 2
# 26 "SARD/000/067/934/CWE122_Heap_Based_Buffer_Overflow__cpp_CWE193_char_memcpy_52c.cpp"
namespace CWE122_Heap_Based_Buffer_Overflow__cpp_CWE193_char_memcpy_52
{





void badSink_c(char * data)
{
    {
        char source[10+1] = "AAAAAAAAAA";


        memcpy(data, source, (strlen(source) + 1) * sizeof(char));
        printLine(data);
        delete [] data;
    }
}
# 64 "SARD/000/067/934/CWE122_Heap_Based_Buffer_Overflow__cpp_CWE193_char_memcpy_52c.cpp"
}
