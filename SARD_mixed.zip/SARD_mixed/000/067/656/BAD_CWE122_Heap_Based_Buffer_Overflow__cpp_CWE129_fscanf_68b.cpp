# 1 "SARD/000/067/656/CWE122_Heap_Based_Buffer_Overflow__cpp_CWE129_fscanf_68b.cpp"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 380 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "SARD/000/067/656/CWE122_Heap_Based_Buffer_Overflow__cpp_CWE129_fscanf_68b.cpp" 2
# 20 "SARD/000/067/656/CWE122_Heap_Based_Buffer_Overflow__cpp_CWE129_fscanf_68b.cpp"
namespace CWE122_Heap_Based_Buffer_Overflow__cpp_CWE129_fscanf_68
{

extern int badData;
extern int goodG2BData;
extern int goodB2GData;



void badSink()
{
    int data = badData;
    {
        int i;
        int * buffer = new int[10];

        for (i = 0; i < 10; i++)
        {
            buffer[i] = 0;
        }


        if (data >= 0)
        {
            buffer[data] = 1;

            for(i = 0; i < 10; i++)
            {
                printIntLine(buffer[i]);
            }
        }
        else
        {
            printLine("ERROR: Array index is negative.");
        }
        delete[] buffer;
    }
}
# 126 "SARD/000/067/656/CWE122_Heap_Based_Buffer_Overflow__cpp_CWE129_fscanf_68b.cpp"
}
