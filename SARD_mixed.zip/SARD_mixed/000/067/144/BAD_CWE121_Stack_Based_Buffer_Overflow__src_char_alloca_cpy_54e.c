# 1 "SARD/000/067/144/CWE121_Stack_Based_Buffer_Overflow__src_char_alloca_cpy_54e.c"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 367 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "SARD/000/067/144/CWE121_Stack_Based_Buffer_Overflow__src_char_alloca_cpy_54e.c" 2
# 25 "SARD/000/067/144/CWE121_Stack_Based_Buffer_Overflow__src_char_alloca_cpy_54e.c"
void CWE121_Stack_Based_Buffer_Overflow__src_char_alloca_cpy_54e_badSink(char * data)
{
    {
        char dest[50] = "";

        strcpy(dest, data);
        printLine(data);
    }
}
