# 1 "SARD/000/067/490/CWE122_Heap_Based_Buffer_Overflow__char_type_overrun_memcpy_07.c"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 367 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "SARD/000/067/490/CWE122_Heap_Based_Buffer_Overflow__char_type_overrun_memcpy_07.c" 2
# 24 "SARD/000/067/490/CWE122_Heap_Based_Buffer_Overflow__char_type_overrun_memcpy_07.c"
typedef struct _charVoid
{
    char charFirst[16];
    void * voidSecond;
    void * voidThird;
} charVoid;




static int staticFive = 5;



void CWE122_Heap_Based_Buffer_Overflow__char_type_overrun_memcpy_07_bad()
{
    if(staticFive==5)
    {
        {
            charVoid * structCharVoid = (charVoid *)malloc(sizeof(charVoid));
            structCharVoid->voidSecond = (void *)"0123456789abcde0123";

            printLine((char *)structCharVoid->voidSecond);

            memcpy(structCharVoid->charFirst, "0123456789abcde0123", sizeof(*structCharVoid));
            structCharVoid->charFirst[(sizeof(structCharVoid->charFirst)/sizeof(char))-1] = '\0';
            printLine((char *)structCharVoid->charFirst);
            printLine((char *)structCharVoid->voidSecond);
            free(structCharVoid);
        }
    }
}
