# 1 "SARD/000/067/849/CWE122_Heap_Based_Buffer_Overflow__cpp_CWE193_char_cpy_72b.cpp"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 380 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "SARD/000/067/849/CWE122_Heap_Based_Buffer_Overflow__cpp_CWE193_char_cpy_72b.cpp" 2
# 27 "SARD/000/067/849/CWE122_Heap_Based_Buffer_Overflow__cpp_CWE193_char_cpy_72b.cpp"
using namespace std;

namespace CWE122_Heap_Based_Buffer_Overflow__cpp_CWE193_char_cpy_72
{



void badSink(vector<char *> dataVector)
{

    char * data = dataVector[2];
    {
        char source[10+1] = "AAAAAAAAAA";

        strcpy(data, source);
        printLine(data);
        delete [] data;
    }
}
# 66 "SARD/000/067/849/CWE122_Heap_Based_Buffer_Overflow__cpp_CWE193_char_cpy_72b.cpp"
}
