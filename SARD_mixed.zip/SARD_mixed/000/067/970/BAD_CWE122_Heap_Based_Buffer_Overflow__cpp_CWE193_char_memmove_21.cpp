# 1 "SARD/000/067/970/CWE122_Heap_Based_Buffer_Overflow__cpp_CWE193_char_memmove_21.cpp"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 380 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "SARD/000/067/970/CWE122_Heap_Based_Buffer_Overflow__cpp_CWE193_char_memmove_21.cpp" 2
# 26 "SARD/000/067/970/CWE122_Heap_Based_Buffer_Overflow__cpp_CWE193_char_memmove_21.cpp"
namespace CWE122_Heap_Based_Buffer_Overflow__cpp_CWE193_char_memmove_21
{




static int badStatic = 0;

static char * badSource(char * data)
{
    if(badStatic)
    {

        data = new char[10];
    }
    return data;
}

void bad()
{
    char * data;
    data = NULL;
    badStatic = 1;
    data = badSource(data);
    {
        char source[10+1] = "AAAAAAAAAA";


        memmove(data, source, (strlen(source) + 1) * sizeof(char));
        printLine(data);
        delete [] data;
    }
    ;
}
# 138 "SARD/000/067/970/CWE122_Heap_Based_Buffer_Overflow__cpp_CWE193_char_memmove_21.cpp"
}
