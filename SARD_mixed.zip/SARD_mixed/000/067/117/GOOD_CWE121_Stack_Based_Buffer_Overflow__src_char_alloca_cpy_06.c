# 1 "SARD/000/067/117/CWE121_Stack_Based_Buffer_Overflow__src_char_alloca_cpy_06.c"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 367 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "SARD/000/067/117/CWE121_Stack_Based_Buffer_Overflow__src_char_alloca_cpy_06.c" 2
# 23 "SARD/000/067/117/CWE121_Stack_Based_Buffer_Overflow__src_char_alloca_cpy_06.c"
static const int STATIC_CONST_FIVE = 5;
# 51 "SARD/000/067/117/CWE121_Stack_Based_Buffer_Overflow__src_char_alloca_cpy_06.c"
static void goodG2B1()
{
    char * data;
    char * dataBuffer = (char *)ALLOCA(100*sizeof(char));
    data = dataBuffer;
    if(STATIC_CONST_FIVE!=5)
    {

        printLine("Benign, fixed string");
    }
    else
    {

        memset(data, 'A', 50-1);
        data[50-1] = '\0';
    }
    {
        char dest[50] = "";

        strcpy(dest, data);
        printLine(data);
    }
}


static void goodG2B2()
{
    char * data;
    char * dataBuffer = (char *)ALLOCA(100*sizeof(char));
    data = dataBuffer;
    if(STATIC_CONST_FIVE==5)
    {

        memset(data, 'A', 50-1);
        data[50-1] = '\0';
    }
    {
        char dest[50] = "";

        strcpy(dest, data);
        printLine(data);
    }
}

void CWE121_Stack_Based_Buffer_Overflow__src_char_alloca_cpy_06_good()
{
    goodG2B1();
    goodG2B2();
}
