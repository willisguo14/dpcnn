# 1 "SARD/000/067/163/CWE121_Stack_Based_Buffer_Overflow__src_char_declare_cat_04.c"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 367 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "SARD/000/067/163/CWE121_Stack_Based_Buffer_Overflow__src_char_declare_cat_04.c" 2
# 25 "SARD/000/067/163/CWE121_Stack_Based_Buffer_Overflow__src_char_declare_cat_04.c"
static const int STATIC_CONST_TRUE = 1;
static const int STATIC_CONST_FALSE = 0;
# 54 "SARD/000/067/163/CWE121_Stack_Based_Buffer_Overflow__src_char_declare_cat_04.c"
static void goodG2B1()
{
    char * data;
    char dataBuffer[100];
    data = dataBuffer;
    if(STATIC_CONST_FALSE)
    {

        printLine("Benign, fixed string");
    }
    else
    {

        memset(data, 'A', 50-1);
        data[50-1] = '\0';
    }
    {
        char dest[50] = "";

        strcat(dest, data);
        printLine(data);
    }
}


static void goodG2B2()
{
    char * data;
    char dataBuffer[100];
    data = dataBuffer;
    if(STATIC_CONST_TRUE)
    {

        memset(data, 'A', 50-1);
        data[50-1] = '\0';
    }
    {
        char dest[50] = "";

        strcat(dest, data);
        printLine(data);
    }
}

void CWE121_Stack_Based_Buffer_Overflow__src_char_declare_cat_04_good()
{
    goodG2B1();
    goodG2B2();
}
