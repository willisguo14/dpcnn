# 1 "SARD/000/067/698/CWE122_Heap_Based_Buffer_Overflow__cpp_CWE129_large_62a.cpp"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 380 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "SARD/000/067/698/CWE122_Heap_Based_Buffer_Overflow__cpp_CWE129_large_62a.cpp" 2
# 20 "SARD/000/067/698/CWE122_Heap_Based_Buffer_Overflow__cpp_CWE129_large_62a.cpp"
namespace CWE122_Heap_Based_Buffer_Overflow__cpp_CWE129_large_62
{




void badSource(int &data);

void bad()
{
    int data;

    data = -1;
    badSource(data);
    {
        int i;
        int * buffer = new int[10];

        for (i = 0; i < 10; i++)
        {
            buffer[i] = 0;
        }


        if (data >= 0)
        {
            buffer[data] = 1;

            for(i = 0; i < 10; i++)
            {
                printIntLine(buffer[i]);
            }
        }
        else
        {
            printLine("ERROR: Array index is negative.");
        }
        delete[] buffer;
    }
}
# 144 "SARD/000/067/698/CWE122_Heap_Based_Buffer_Overflow__cpp_CWE129_large_62a.cpp"
}
