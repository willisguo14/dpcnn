# 1 "SARD/000/067/153/CWE121_Stack_Based_Buffer_Overflow__src_char_alloca_cpy_72b.cpp"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 380 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "SARD/000/067/153/CWE121_Stack_Based_Buffer_Overflow__src_char_alloca_cpy_72b.cpp" 2
# 22 "SARD/000/067/153/CWE121_Stack_Based_Buffer_Overflow__src_char_alloca_cpy_72b.cpp"
using namespace std;

namespace CWE121_Stack_Based_Buffer_Overflow__src_char_alloca_cpy_72
{



void badSink(vector<char *> dataVector)
{

    char * data = dataVector[2];
    {
        char dest[50] = "";

        strcpy(dest, data);
        printLine(data);
    }
}
# 59 "SARD/000/067/153/CWE121_Stack_Based_Buffer_Overflow__src_char_alloca_cpy_72b.cpp"
}
