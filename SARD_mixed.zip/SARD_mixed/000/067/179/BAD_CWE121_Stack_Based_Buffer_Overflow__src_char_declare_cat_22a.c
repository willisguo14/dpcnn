# 1 "SARD/000/067/179/CWE121_Stack_Based_Buffer_Overflow__src_char_declare_cat_22a.c"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 367 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "SARD/000/067/179/CWE121_Stack_Based_Buffer_Overflow__src_char_declare_cat_22a.c" 2
# 24 "SARD/000/067/179/CWE121_Stack_Based_Buffer_Overflow__src_char_declare_cat_22a.c"
int CWE121_Stack_Based_Buffer_Overflow__src_char_declare_cat_22_badGlobal = 0;

char * CWE121_Stack_Based_Buffer_Overflow__src_char_declare_cat_22_badSource(char * data);

void CWE121_Stack_Based_Buffer_Overflow__src_char_declare_cat_22_bad()
{
    char * data;
    char dataBuffer[100];
    data = dataBuffer;
    CWE121_Stack_Based_Buffer_Overflow__src_char_declare_cat_22_badGlobal = 1;
    data = CWE121_Stack_Based_Buffer_Overflow__src_char_declare_cat_22_badSource(data);
    {
        char dest[50] = "";

        strcat(dest, data);
        printLine(data);
    }
}
