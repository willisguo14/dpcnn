# 1 "SARD/000/067/179/CWE121_Stack_Based_Buffer_Overflow__src_char_declare_cat_22a.c"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 367 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "SARD/000/067/179/CWE121_Stack_Based_Buffer_Overflow__src_char_declare_cat_22a.c" 2
# 48 "SARD/000/067/179/CWE121_Stack_Based_Buffer_Overflow__src_char_declare_cat_22a.c"
int CWE121_Stack_Based_Buffer_Overflow__src_char_declare_cat_22_goodG2B1Global = 0;
int CWE121_Stack_Based_Buffer_Overflow__src_char_declare_cat_22_goodG2B2Global = 0;


char * CWE121_Stack_Based_Buffer_Overflow__src_char_declare_cat_22_goodG2B1Source(char * data);

static void goodG2B1()
{
    char * data;
    char dataBuffer[100];
    data = dataBuffer;
    CWE121_Stack_Based_Buffer_Overflow__src_char_declare_cat_22_goodG2B1Global = 0;
    data = CWE121_Stack_Based_Buffer_Overflow__src_char_declare_cat_22_goodG2B1Source(data);
    {
        char dest[50] = "";

        strcat(dest, data);
        printLine(data);
    }
}


char * CWE121_Stack_Based_Buffer_Overflow__src_char_declare_cat_22_goodG2B2Source(char * data);

static void goodG2B2()
{
    char * data;
    char dataBuffer[100];
    data = dataBuffer;
    CWE121_Stack_Based_Buffer_Overflow__src_char_declare_cat_22_goodG2B2Global = 1;
    data = CWE121_Stack_Based_Buffer_Overflow__src_char_declare_cat_22_goodG2B2Source(data);
    {
        char dest[50] = "";

        strcat(dest, data);
        printLine(data);
    }
}

void CWE121_Stack_Based_Buffer_Overflow__src_char_declare_cat_22_good()
{
    goodG2B1();
    goodG2B2();
}
