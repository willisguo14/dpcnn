# 1 "SARD/000/067/493/CWE122_Heap_Based_Buffer_Overflow__char_type_overrun_memcpy_10.c"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 367 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "SARD/000/067/493/CWE122_Heap_Based_Buffer_Overflow__char_type_overrun_memcpy_10.c" 2
# 24 "SARD/000/067/493/CWE122_Heap_Based_Buffer_Overflow__char_type_overrun_memcpy_10.c"
typedef struct _charVoid
{
    char charFirst[16];
    void * voidSecond;
    void * voidThird;
} charVoid;
# 57 "SARD/000/067/493/CWE122_Heap_Based_Buffer_Overflow__char_type_overrun_memcpy_10.c"
static void good1()
{
    if(globalFalse)
    {

        printLine("Benign, fixed string");
    }
    else
    {
        {
            charVoid * structCharVoid = (charVoid *)malloc(sizeof(charVoid));
            structCharVoid->voidSecond = (void *)"0123456789abcde0123";

            printLine((char *)structCharVoid->voidSecond);

            memcpy(structCharVoid->charFirst, "0123456789abcde0123", sizeof(structCharVoid->charFirst));
            structCharVoid->charFirst[(sizeof(structCharVoid->charFirst)/sizeof(char))-1] = '\0';
            printLine((char *)structCharVoid->charFirst);
            printLine((char *)structCharVoid->voidSecond);
            free(structCharVoid);
        }
    }
}


static void good2()
{
    if(globalTrue)
    {
        {
            charVoid * structCharVoid = (charVoid *)malloc(sizeof(charVoid));
            structCharVoid->voidSecond = (void *)"0123456789abcde0123";

            printLine((char *)structCharVoid->voidSecond);

            memcpy(structCharVoid->charFirst, "0123456789abcde0123", sizeof(structCharVoid->charFirst));
            structCharVoid->charFirst[(sizeof(structCharVoid->charFirst)/sizeof(char))-1] = '\0';
            printLine((char *)structCharVoid->charFirst);
            printLine((char *)structCharVoid->voidSecond);
            free(structCharVoid);
        }
    }
}

void CWE122_Heap_Based_Buffer_Overflow__char_type_overrun_memcpy_10_good()
{
    good1();
    good2();
}
