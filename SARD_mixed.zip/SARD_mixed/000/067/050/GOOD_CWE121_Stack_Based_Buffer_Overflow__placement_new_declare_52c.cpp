# 1 "SARD/000/067/050/CWE121_Stack_Based_Buffer_Overflow__placement_new_declare_52c.cpp"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 380 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "SARD/000/067/050/CWE121_Stack_Based_Buffer_Overflow__placement_new_declare_52c.cpp" 2
# 20 "SARD/000/067/050/CWE121_Stack_Based_Buffer_Overflow__placement_new_declare_52c.cpp"
namespace CWE121_Stack_Based_Buffer_Overflow__placement_new_declare_52
{
# 47 "SARD/000/067/050/CWE121_Stack_Based_Buffer_Overflow__placement_new_declare_52c.cpp"
void goodG2BSink_c(char * data)
{
    {





        TwoIntsClass * classTwo = new(data) TwoIntsClass;

        classTwo->intOne = 5;
        classTwo->intTwo = 10;
        printIntLine(classTwo->intOne);

    }
}


void goodB2GSink_c(char * data)
{
    {





        OneIntClass * classOne = new(data) OneIntClass;

        classOne->intOne = 5;
        printIntLine(classOne->intOne);
    }
}



}
