# 1 "SARD/000/067/621/CWE122_Heap_Based_Buffer_Overflow__cpp_CWE129_fscanf_06.cpp"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 380 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "SARD/000/067/621/CWE122_Heap_Based_Buffer_Overflow__cpp_CWE129_fscanf_06.cpp" 2
# 23 "SARD/000/067/621/CWE122_Heap_Based_Buffer_Overflow__cpp_CWE129_fscanf_06.cpp"
static const int STATIC_CONST_FIVE = 5;

namespace CWE122_Heap_Based_Buffer_Overflow__cpp_CWE129_fscanf_06
{



void bad()
{
    int data;

    data = -1;
    if(STATIC_CONST_FIVE==5)
    {

        fscanf(stdin, "%d", &data);
    }
    if(STATIC_CONST_FIVE==5)
    {
        {
            int i;
            int * buffer = new int[10];

            for (i = 0; i < 10; i++)
            {
                buffer[i] = 0;
            }


            if (data >= 0)
            {
                buffer[data] = 1;

                for(i = 0; i < 10; i++)
                {
                    printIntLine(buffer[i]);
                }
            }
            else
            {
                printLine("ERROR: Array index is negative.");
            }
            delete[] buffer;
        }
    }
}
# 258 "SARD/000/067/621/CWE122_Heap_Based_Buffer_Overflow__cpp_CWE129_fscanf_06.cpp"
}
