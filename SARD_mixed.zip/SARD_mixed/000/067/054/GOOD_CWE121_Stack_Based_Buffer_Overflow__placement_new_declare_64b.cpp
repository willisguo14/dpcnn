# 1 "SARD/000/067/054/CWE121_Stack_Based_Buffer_Overflow__placement_new_declare_64b.cpp"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 380 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "SARD/000/067/054/CWE121_Stack_Based_Buffer_Overflow__placement_new_declare_64b.cpp" 2
# 20 "SARD/000/067/054/CWE121_Stack_Based_Buffer_Overflow__placement_new_declare_64b.cpp"
namespace CWE121_Stack_Based_Buffer_Overflow__placement_new_declare_64
{
# 51 "SARD/000/067/054/CWE121_Stack_Based_Buffer_Overflow__placement_new_declare_64b.cpp"
void goodG2BSink(void * dataVoidPtr)
{

    char * * dataPtr = (char * *)dataVoidPtr;

    char * data = (*dataPtr);
    {





        TwoIntsClass * classTwo = new(data) TwoIntsClass;

        classTwo->intOne = 5;
        classTwo->intTwo = 10;
        printIntLine(classTwo->intOne);

    }
}


void goodB2GSink(void * dataVoidPtr)
{

    char * * dataPtr = (char * *)dataVoidPtr;

    char * data = (*dataPtr);
    {





        OneIntClass * classOne = new(data) OneIntClass;

        classOne->intOne = 5;
        printIntLine(classOne->intOne);
    }
}



}
