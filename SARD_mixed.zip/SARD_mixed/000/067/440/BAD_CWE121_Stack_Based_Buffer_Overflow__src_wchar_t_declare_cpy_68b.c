# 1 "SARD/000/067/440/CWE121_Stack_Based_Buffer_Overflow__src_wchar_t_declare_cpy_68b.c"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 367 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "SARD/000/067/440/CWE121_Stack_Based_Buffer_Overflow__src_wchar_t_declare_cpy_68b.c" 2
# 21 "SARD/000/067/440/CWE121_Stack_Based_Buffer_Overflow__src_wchar_t_declare_cpy_68b.c"
extern wchar_t * CWE121_Stack_Based_Buffer_Overflow__src_wchar_t_declare_cpy_68_badData;
extern wchar_t * CWE121_Stack_Based_Buffer_Overflow__src_wchar_t_declare_cpy_68_goodG2BData;





void CWE121_Stack_Based_Buffer_Overflow__src_wchar_t_declare_cpy_68b_badSink()
{
    wchar_t * data = CWE121_Stack_Based_Buffer_Overflow__src_wchar_t_declare_cpy_68_badData;
    {
        wchar_t dest[50] = L"";

        wcscpy(dest, data);
        printWLine(data);
    }
}
