# 1 "SARD/000/067/845/CWE122_Heap_Based_Buffer_Overflow__cpp_CWE193_char_cpy_65b.cpp"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 380 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "SARD/000/067/845/CWE122_Heap_Based_Buffer_Overflow__cpp_CWE193_char_cpy_65b.cpp" 2
# 26 "SARD/000/067/845/CWE122_Heap_Based_Buffer_Overflow__cpp_CWE193_char_cpy_65b.cpp"
namespace CWE122_Heap_Based_Buffer_Overflow__cpp_CWE193_char_cpy_65
{
# 47 "SARD/000/067/845/CWE122_Heap_Based_Buffer_Overflow__cpp_CWE193_char_cpy_65b.cpp"
void goodG2BSink(char * data)
{
    {
        char source[10+1] = "AAAAAAAAAA";

        strcpy(data, source);
        printLine(data);
        delete [] data;
    }
}



}
