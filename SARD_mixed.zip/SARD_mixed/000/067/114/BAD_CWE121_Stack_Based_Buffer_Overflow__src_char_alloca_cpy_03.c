# 1 "SARD/000/067/114/CWE121_Stack_Based_Buffer_Overflow__src_char_alloca_cpy_03.c"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 367 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "SARD/000/067/114/CWE121_Stack_Based_Buffer_Overflow__src_char_alloca_cpy_03.c" 2
# 23 "SARD/000/067/114/CWE121_Stack_Based_Buffer_Overflow__src_char_alloca_cpy_03.c"
void CWE121_Stack_Based_Buffer_Overflow__src_char_alloca_cpy_03_bad()
{
    char * data;
    char * dataBuffer = (char *)ALLOCA(100*sizeof(char));
    data = dataBuffer;
    if(5==5)
    {

        memset(data, 'A', 100-1);
        data[100-1] = '\0';
    }
    {
        char dest[50] = "";

        strcpy(dest, data);
        printLine(data);
    }
}
