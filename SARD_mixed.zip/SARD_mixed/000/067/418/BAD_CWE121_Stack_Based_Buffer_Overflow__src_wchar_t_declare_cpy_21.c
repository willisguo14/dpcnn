# 1 "SARD/000/067/418/CWE121_Stack_Based_Buffer_Overflow__src_wchar_t_declare_cpy_21.c"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 367 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "SARD/000/067/418/CWE121_Stack_Based_Buffer_Overflow__src_wchar_t_declare_cpy_21.c" 2
# 24 "SARD/000/067/418/CWE121_Stack_Based_Buffer_Overflow__src_wchar_t_declare_cpy_21.c"
static int badStatic = 0;

static wchar_t * badSource(wchar_t * data)
{
    if(badStatic)
    {

        wmemset(data, L'A', 100-1);
        data[100-1] = L'\0';
    }
    return data;
}

void CWE121_Stack_Based_Buffer_Overflow__src_wchar_t_declare_cpy_21_bad()
{
    wchar_t * data;
    wchar_t dataBuffer[100];
    data = dataBuffer;
    badStatic = 1;
    data = badSource(data);
    {
        wchar_t dest[50] = L"";

        wcscpy(dest, data);
        printWLine(data);
    }
}
