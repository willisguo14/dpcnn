# 1 "SARD/000/067/337/CWE121_Stack_Based_Buffer_Overflow__src_wchar_t_alloca_cpy_61a.c"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 367 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "SARD/000/067/337/CWE121_Stack_Based_Buffer_Overflow__src_wchar_t_alloca_cpy_61a.c" 2
# 45 "SARD/000/067/337/CWE121_Stack_Based_Buffer_Overflow__src_wchar_t_alloca_cpy_61a.c"
wchar_t * CWE121_Stack_Based_Buffer_Overflow__src_wchar_t_alloca_cpy_61b_goodG2BSource(wchar_t * data);

static void goodG2B()
{
    wchar_t * data;
    wchar_t * dataBuffer = (wchar_t *)ALLOCA(100*sizeof(wchar_t));
    data = dataBuffer;
    data = CWE121_Stack_Based_Buffer_Overflow__src_wchar_t_alloca_cpy_61b_goodG2BSource(data);
    {
        wchar_t dest[50] = L"";

        wcscpy(dest, data);
        printWLine(data);
    }
}

void CWE121_Stack_Based_Buffer_Overflow__src_wchar_t_alloca_cpy_61_good()
{
    goodG2B();
}
