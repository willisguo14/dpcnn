# 1 "SARD/000/067/138/CWE121_Stack_Based_Buffer_Overflow__src_char_alloca_cpy_43.cpp"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 380 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "SARD/000/067/138/CWE121_Stack_Based_Buffer_Overflow__src_char_alloca_cpy_43.cpp" 2
# 21 "SARD/000/067/138/CWE121_Stack_Based_Buffer_Overflow__src_char_alloca_cpy_43.cpp"
namespace CWE121_Stack_Based_Buffer_Overflow__src_char_alloca_cpy_43
{



static void badSource(char * &data)
{

    memset(data, 'A', 100-1);
    data[100-1] = '\0';
}

void bad()
{
    char * data;
    char * dataBuffer = (char *)ALLOCA(100*sizeof(char));
    data = dataBuffer;
    badSource(data);
    {
        char dest[50] = "";

        strcpy(dest, data);
        printLine(data);
    }
}
# 80 "SARD/000/067/138/CWE121_Stack_Based_Buffer_Overflow__src_char_alloca_cpy_43.cpp"
}
