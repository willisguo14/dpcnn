# 1 "SARD/000/067/695/CWE122_Heap_Based_Buffer_Overflow__cpp_CWE129_large_53d.cpp"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 380 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "SARD/000/067/695/CWE122_Heap_Based_Buffer_Overflow__cpp_CWE129_large_53d.cpp" 2
# 20 "SARD/000/067/695/CWE122_Heap_Based_Buffer_Overflow__cpp_CWE129_large_53d.cpp"
namespace CWE122_Heap_Based_Buffer_Overflow__cpp_CWE129_large_53
{
# 59 "SARD/000/067/695/CWE122_Heap_Based_Buffer_Overflow__cpp_CWE129_large_53d.cpp"
void goodG2BSink_d(int data)
{
    {
        int i;
        int * buffer = new int[10];

        for (i = 0; i < 10; i++)
        {
            buffer[i] = 0;
        }


        if (data >= 0)
        {
            buffer[data] = 1;

            for(i = 0; i < 10; i++)
            {
                printIntLine(buffer[i]);
            }
        }
        else
        {
            printLine("ERROR: Array index is negative.");
        }
        delete[] buffer;
    }
}


void goodB2GSink_d(int data)
{
    {
        int i;
        int * buffer = new int[10];

        for (i = 0; i < 10; i++)
        {
            buffer[i] = 0;
        }

        if (data >= 0 && data < (10))
        {
            buffer[data] = 1;

            for(i = 0; i < 10; i++)
            {
                printIntLine(buffer[i]);
            }
        }
        else
        {
            printLine("ERROR: Array index is out-of-bounds");
        }
        delete[] buffer;
    }
}



}
