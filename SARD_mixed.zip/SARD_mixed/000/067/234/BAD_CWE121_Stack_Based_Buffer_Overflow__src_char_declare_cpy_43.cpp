# 1 "SARD/000/067/234/CWE121_Stack_Based_Buffer_Overflow__src_char_declare_cpy_43.cpp"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 380 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "SARD/000/067/234/CWE121_Stack_Based_Buffer_Overflow__src_char_declare_cpy_43.cpp" 2
# 21 "SARD/000/067/234/CWE121_Stack_Based_Buffer_Overflow__src_char_declare_cpy_43.cpp"
namespace CWE121_Stack_Based_Buffer_Overflow__src_char_declare_cpy_43
{



static void badSource(char * &data)
{

    memset(data, 'A', 100-1);
    data[100-1] = '\0';
}

void bad()
{
    char * data;
    char dataBuffer[100];
    data = dataBuffer;
    badSource(data);
    {
        char dest[50] = "";

        strcpy(dest, data);
        printLine(data);
    }
}
# 80 "SARD/000/067/234/CWE121_Stack_Based_Buffer_Overflow__src_char_declare_cpy_43.cpp"
}
