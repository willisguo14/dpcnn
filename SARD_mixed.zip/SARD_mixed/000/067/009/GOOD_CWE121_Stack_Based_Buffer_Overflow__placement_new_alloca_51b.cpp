# 1 "SARD/000/067/009/CWE121_Stack_Based_Buffer_Overflow__placement_new_alloca_51b.cpp"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 380 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "SARD/000/067/009/CWE121_Stack_Based_Buffer_Overflow__placement_new_alloca_51b.cpp" 2
# 20 "SARD/000/067/009/CWE121_Stack_Based_Buffer_Overflow__placement_new_alloca_51b.cpp"
namespace CWE121_Stack_Based_Buffer_Overflow__placement_new_alloca_51
{
# 47 "SARD/000/067/009/CWE121_Stack_Based_Buffer_Overflow__placement_new_alloca_51b.cpp"
void goodG2BSink(char * data)
{
    {





        TwoIntsClass * classTwo = new(data) TwoIntsClass;

        classTwo->intOne = 5;
        classTwo->intTwo = 10;
        printIntLine(classTwo->intOne);

    }
}


void goodB2GSink(char * data)
{
    {





        OneIntClass * classOne = new(data) OneIntClass;

        classOne->intOne = 5;
        printIntLine(classOne->intOne);
    }
}



}
