# 1 "SARD/000/067/818/CWE122_Heap_Based_Buffer_Overflow__cpp_CWE193_char_cpy_11.cpp"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 380 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "SARD/000/067/818/CWE122_Heap_Based_Buffer_Overflow__cpp_CWE193_char_cpy_11.cpp" 2
# 26 "SARD/000/067/818/CWE122_Heap_Based_Buffer_Overflow__cpp_CWE193_char_cpy_11.cpp"
namespace CWE122_Heap_Based_Buffer_Overflow__cpp_CWE193_char_cpy_11
{



void bad()
{
    char * data;
    data = NULL;
    if(globalReturnsTrue())
    {

        data = new char[10];
    }
    {
        char source[10+1] = "AAAAAAAAAA";

        strcpy(data, source);
        printLine(data);
        delete [] data;
    }
}
# 104 "SARD/000/067/818/CWE122_Heap_Based_Buffer_Overflow__cpp_CWE193_char_cpy_11.cpp"
}
