# 1 "SARD/000/067/984/CWE122_Heap_Based_Buffer_Overflow__cpp_CWE193_char_memmove_54e.cpp"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 380 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "SARD/000/067/984/CWE122_Heap_Based_Buffer_Overflow__cpp_CWE193_char_memmove_54e.cpp" 2
# 26 "SARD/000/067/984/CWE122_Heap_Based_Buffer_Overflow__cpp_CWE193_char_memmove_54e.cpp"
namespace CWE122_Heap_Based_Buffer_Overflow__cpp_CWE193_char_memmove_54
{





void badSink_e(char * data)
{
    {
        char source[10+1] = "AAAAAAAAAA";


        memmove(data, source, (strlen(source) + 1) * sizeof(char));
        printLine(data);
        delete [] data;
    }
}
# 64 "SARD/000/067/984/CWE122_Heap_Based_Buffer_Overflow__cpp_CWE193_char_memmove_54e.cpp"
}
