# 1 "SARD/000/067/958/CWE122_Heap_Based_Buffer_Overflow__cpp_CWE193_char_memmove_07.cpp"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 380 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "SARD/000/067/958/CWE122_Heap_Based_Buffer_Overflow__cpp_CWE193_char_memmove_07.cpp" 2
# 29 "SARD/000/067/958/CWE122_Heap_Based_Buffer_Overflow__cpp_CWE193_char_memmove_07.cpp"
static int staticFive = 5;

namespace CWE122_Heap_Based_Buffer_Overflow__cpp_CWE193_char_memmove_07
{



void bad()
{
    char * data;
    data = NULL;
    if(staticFive==5)
    {

        data = new char[10];
    }
    {
        char source[10+1] = "AAAAAAAAAA";


        memmove(data, source, (strlen(source) + 1) * sizeof(char));
        printLine(data);
        delete [] data;
    }
}
# 112 "SARD/000/067/958/CWE122_Heap_Based_Buffer_Overflow__cpp_CWE193_char_memmove_07.cpp"
}
