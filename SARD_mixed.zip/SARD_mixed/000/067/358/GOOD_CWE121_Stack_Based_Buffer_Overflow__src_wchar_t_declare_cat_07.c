# 1 "SARD/000/067/358/CWE121_Stack_Based_Buffer_Overflow__src_wchar_t_declare_cat_07.c"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 367 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "SARD/000/067/358/CWE121_Stack_Based_Buffer_Overflow__src_wchar_t_declare_cat_07.c" 2
# 25 "SARD/000/067/358/CWE121_Stack_Based_Buffer_Overflow__src_wchar_t_declare_cat_07.c"
static int staticFive = 5;
# 53 "SARD/000/067/358/CWE121_Stack_Based_Buffer_Overflow__src_wchar_t_declare_cat_07.c"
static void goodG2B1()
{
    wchar_t * data;
    wchar_t dataBuffer[100];
    data = dataBuffer;
    if(staticFive!=5)
    {

        printLine("Benign, fixed string");
    }
    else
    {

        wmemset(data, L'A', 50-1);
        data[50-1] = L'\0';
    }
    {
        wchar_t dest[50] = L"";

        wcscat(dest, data);
        printWLine(data);
    }
}


static void goodG2B2()
{
    wchar_t * data;
    wchar_t dataBuffer[100];
    data = dataBuffer;
    if(staticFive==5)
    {

        wmemset(data, L'A', 50-1);
        data[50-1] = L'\0';
    }
    {
        wchar_t dest[50] = L"";

        wcscat(dest, data);
        printWLine(data);
    }
}

void CWE121_Stack_Based_Buffer_Overflow__src_wchar_t_declare_cat_07_good()
{
    goodG2B1();
    goodG2B2();
}
