# 1 "SARD/000/067/710/CWE122_Heap_Based_Buffer_Overflow__cpp_CWE129_large_83_bad.cpp"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 380 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "SARD/000/067/710/CWE122_Heap_Based_Buffer_Overflow__cpp_CWE129_large_83_bad.cpp" 2
# 22 "SARD/000/067/710/CWE122_Heap_Based_Buffer_Overflow__cpp_CWE129_large_83_bad.cpp"
namespace CWE122_Heap_Based_Buffer_Overflow__cpp_CWE129_large_83
{
CWE122_Heap_Based_Buffer_Overflow__cpp_CWE129_large_83_bad::CWE122_Heap_Based_Buffer_Overflow__cpp_CWE129_large_83_bad(int dataCopy)
{
    data = dataCopy;

    data = 10;
}

CWE122_Heap_Based_Buffer_Overflow__cpp_CWE129_large_83_bad::~CWE122_Heap_Based_Buffer_Overflow__cpp_CWE129_large_83_bad()
{
    {
        int i;
        int * buffer = new int[10];

        for (i = 0; i < 10; i++)
        {
            buffer[i] = 0;
        }


        if (data >= 0)
        {
            buffer[data] = 1;

            for(i = 0; i < 10; i++)
            {
                printIntLine(buffer[i]);
            }
        }
        else
        {
            printLine("ERROR: Array index is negative.");
        }
        delete[] buffer;
    }
}
}
