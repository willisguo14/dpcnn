# 1 "SARD/000/067/594/CWE122_Heap_Based_Buffer_Overflow__cpp_CWE129_fgets_43.cpp"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 380 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "SARD/000/067/594/CWE122_Heap_Based_Buffer_Overflow__cpp_CWE129_fgets_43.cpp" 2
# 22 "SARD/000/067/594/CWE122_Heap_Based_Buffer_Overflow__cpp_CWE129_fgets_43.cpp"
namespace CWE122_Heap_Based_Buffer_Overflow__cpp_CWE129_fgets_43
{
# 82 "SARD/000/067/594/CWE122_Heap_Based_Buffer_Overflow__cpp_CWE129_fgets_43.cpp"
static void goodG2BSource(int &data)
{


    data = 7;
}

static void goodG2B()
{
    int data;

    data = -1;
    goodG2BSource(data);
    {
        int i;
        int * buffer = new int[10];

        for (i = 0; i < 10; i++)
        {
            buffer[i] = 0;
        }


        if (data >= 0)
        {
            buffer[data] = 1;

            for(i = 0; i < 10; i++)
            {
                printIntLine(buffer[i]);
            }
        }
        else
        {
            printLine("ERROR: Array index is negative.");
        }
        delete[] buffer;
    }
}


static void goodB2GSource(int &data)
{
    {
        char inputBuffer[(3 * sizeof(data) + 2)] = "";

        if (fgets(inputBuffer, (3 * sizeof(data) + 2), stdin) != NULL)
        {

            data = atoi(inputBuffer);
        }
        else
        {
            printLine("fgets() failed.");
        }
    }
}

static void goodB2G()
{
    int data;

    data = -1;
    goodB2GSource(data);
    {
        int i;
        int * buffer = new int[10];

        for (i = 0; i < 10; i++)
        {
            buffer[i] = 0;
        }

        if (data >= 0 && data < (10))
        {
            buffer[data] = 1;

            for(i = 0; i < 10; i++)
            {
                printIntLine(buffer[i]);
            }
        }
        else
        {
            printLine("ERROR: Array index is out-of-bounds");
        }
        delete[] buffer;
    }
}

void good()
{
    goodG2B();
    goodB2G();
}



}
