# 1 "SARD/000/067/326/CWE121_Stack_Based_Buffer_Overflow__src_wchar_t_alloca_cpy_33.cpp"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 380 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "SARD/000/067/326/CWE121_Stack_Based_Buffer_Overflow__src_wchar_t_alloca_cpy_33.cpp" 2
# 21 "SARD/000/067/326/CWE121_Stack_Based_Buffer_Overflow__src_wchar_t_alloca_cpy_33.cpp"
namespace CWE121_Stack_Based_Buffer_Overflow__src_wchar_t_alloca_cpy_33
{
# 51 "SARD/000/067/326/CWE121_Stack_Based_Buffer_Overflow__src_wchar_t_alloca_cpy_33.cpp"
static void goodG2B()
{
    wchar_t * data;
    wchar_t * &dataRef = data;
    wchar_t * dataBuffer = (wchar_t *)ALLOCA(100*sizeof(wchar_t));
    data = dataBuffer;

    wmemset(data, L'A', 50-1);
    data[50-1] = L'\0';
    {
        wchar_t * data = dataRef;
        {
            wchar_t dest[50] = L"";

            wcscpy(dest, data);
            printWLine(data);
        }
    }
}

void good()
{
    goodG2B();
}



}
