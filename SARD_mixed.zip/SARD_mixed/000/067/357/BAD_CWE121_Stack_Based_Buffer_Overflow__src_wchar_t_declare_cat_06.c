# 1 "SARD/000/067/357/CWE121_Stack_Based_Buffer_Overflow__src_wchar_t_declare_cat_06.c"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 367 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "SARD/000/067/357/CWE121_Stack_Based_Buffer_Overflow__src_wchar_t_declare_cat_06.c" 2
# 23 "SARD/000/067/357/CWE121_Stack_Based_Buffer_Overflow__src_wchar_t_declare_cat_06.c"
static const int STATIC_CONST_FIVE = 5;



void CWE121_Stack_Based_Buffer_Overflow__src_wchar_t_declare_cat_06_bad()
{
    wchar_t * data;
    wchar_t dataBuffer[100];
    data = dataBuffer;
    if(STATIC_CONST_FIVE==5)
    {

        wmemset(data, L'A', 100-1);
        data[100-1] = L'\0';
    }
    {
        wchar_t dest[50] = L"";

        wcscat(dest, data);
        printWLine(data);
    }
}
