# 1 "SARD/000/067/197/CWE121_Stack_Based_Buffer_Overflow__src_char_declare_cat_65b.c"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 367 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "SARD/000/067/197/CWE121_Stack_Based_Buffer_Overflow__src_char_declare_cat_65b.c" 2
# 38 "SARD/000/067/197/CWE121_Stack_Based_Buffer_Overflow__src_char_declare_cat_65b.c"
void CWE121_Stack_Based_Buffer_Overflow__src_char_declare_cat_65b_goodG2BSink(char * data)
{
    {
        char dest[50] = "";

        strcat(dest, data);
        printLine(data);
    }
}
