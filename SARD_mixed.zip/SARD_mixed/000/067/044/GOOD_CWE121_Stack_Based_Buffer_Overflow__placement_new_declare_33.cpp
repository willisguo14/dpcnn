# 1 "SARD/000/067/044/CWE121_Stack_Based_Buffer_Overflow__placement_new_declare_33.cpp"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 380 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "SARD/000/067/044/CWE121_Stack_Based_Buffer_Overflow__placement_new_declare_33.cpp" 2
# 20 "SARD/000/067/044/CWE121_Stack_Based_Buffer_Overflow__placement_new_declare_33.cpp"
namespace CWE121_Stack_Based_Buffer_Overflow__placement_new_declare_33
{
# 56 "SARD/000/067/044/CWE121_Stack_Based_Buffer_Overflow__placement_new_declare_33.cpp"
static void goodG2B()
{
    char * data;
    char * &dataRef = data;
    char dataBadBuffer[sizeof(OneIntClass)];
    char dataGoodBuffer[sizeof(TwoIntsClass)];

    data = dataGoodBuffer;
    {
        char * data = dataRef;
        {





            TwoIntsClass * classTwo = new(data) TwoIntsClass;

            classTwo->intOne = 5;
            classTwo->intTwo = 10;
            printIntLine(classTwo->intOne);

        }
    }
}


static void goodB2G()
{
    char * data;
    char * &dataRef = data;
    char dataBadBuffer[sizeof(OneIntClass)];
    char dataGoodBuffer[sizeof(TwoIntsClass)];

    data = dataBadBuffer;
    {
        char * data = dataRef;
        {





            OneIntClass * classOne = new(data) OneIntClass;

            classOne->intOne = 5;
            printIntLine(classOne->intOne);
        }
    }
}

void good()
{
    goodG2B();
    goodB2G();
}



}
