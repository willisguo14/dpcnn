# 1 "SARD/000/067/739/CWE122_Heap_Based_Buffer_Overflow__cpp_CWE129_listen_socket_44.cpp"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 380 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "SARD/000/067/739/CWE122_Heap_Based_Buffer_Overflow__cpp_CWE129_listen_socket_44.cpp" 2
# 42 "SARD/000/067/739/CWE122_Heap_Based_Buffer_Overflow__cpp_CWE129_listen_socket_44.cpp"
namespace CWE122_Heap_Based_Buffer_Overflow__cpp_CWE129_listen_socket_44
{
# 161 "SARD/000/067/739/CWE122_Heap_Based_Buffer_Overflow__cpp_CWE129_listen_socket_44.cpp"
static void goodG2BSink(int data)
{
    {
        int i;
        int * buffer = new int[10];

        for (i = 0; i < 10; i++)
        {
            buffer[i] = 0;
        }


        if (data >= 0)
        {
            buffer[data] = 1;

            for(i = 0; i < 10; i++)
            {
                printIntLine(buffer[i]);
            }
        }
        else
        {
            printLine("ERROR: Array index is negative.");
        }
        delete[] buffer;
    }
}

static void goodG2B()
{
    int data;
    void (*funcPtr) (int) = goodG2BSink;

    data = -1;


    data = 7;
    funcPtr(data);
}


static void goodB2GSink(int data)
{
    {
        int i;
        int * buffer = new int[10];

        for (i = 0; i < 10; i++)
        {
            buffer[i] = 0;
        }

        if (data >= 0 && data < (10))
        {
            buffer[data] = 1;

            for(i = 0; i < 10; i++)
            {
                printIntLine(buffer[i]);
            }
        }
        else
        {
            printLine("ERROR: Array index is out-of-bounds");
        }
        delete[] buffer;
    }
}

static void goodB2G()
{
    int data;
    void (*funcPtr) (int) = goodB2GSink;

    data = -1;
    {




        int recvResult;
        struct sockaddr_in service;
        int listenSocket = -1;
        int acceptSocket = -1;
        char inputBuffer[(3 * sizeof(data) + 2)];
        do
        {
# 257 "SARD/000/067/739/CWE122_Heap_Based_Buffer_Overflow__cpp_CWE129_listen_socket_44.cpp"
            listenSocket = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
            if (listenSocket == -1)
            {
                break;
            }
            memset(&service, 0, sizeof(service));
            service.sin_family = AF_INET;
            service.sin_addr.s_addr = INADDR_ANY;
            service.sin_port = htons(27015);
            if (bind(listenSocket, (struct sockaddr*)&service, sizeof(service)) == -1)
            {
                break;
            }
            if (listen(listenSocket, 5) == -1)
            {
                break;
            }
            acceptSocket = accept(listenSocket, NULL, NULL);
            if (acceptSocket == -1)
            {
                break;
            }

            recvResult = recv(acceptSocket, inputBuffer, (3 * sizeof(data) + 2) - 1, 0);
            if (recvResult == -1 || recvResult == 0)
            {
                break;
            }

            inputBuffer[recvResult] = '\0';

            data = atoi(inputBuffer);
        }
        while (0);
        if (listenSocket != -1)
        {
            close(listenSocket);
        }
        if (acceptSocket != -1)
        {
            close(acceptSocket);
        }






    }
    funcPtr(data);
}

void good()
{
    goodG2B();
    goodB2G();
}



}
