# 1 "SARD/000/067/345/CWE121_Stack_Based_Buffer_Overflow__src_wchar_t_alloca_cpy_72b.cpp"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 380 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "SARD/000/067/345/CWE121_Stack_Based_Buffer_Overflow__src_wchar_t_alloca_cpy_72b.cpp" 2
# 22 "SARD/000/067/345/CWE121_Stack_Based_Buffer_Overflow__src_wchar_t_alloca_cpy_72b.cpp"
using namespace std;

namespace CWE121_Stack_Based_Buffer_Overflow__src_wchar_t_alloca_cpy_72
{



void badSink(vector<wchar_t *> dataVector)
{

    wchar_t * data = dataVector[2];
    {
        wchar_t dest[50] = L"";

        wcscpy(dest, data);
        printWLine(data);
    }
}
# 59 "SARD/000/067/345/CWE121_Stack_Based_Buffer_Overflow__src_wchar_t_alloca_cpy_72b.cpp"
}
