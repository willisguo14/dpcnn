# 1 "SARD/000/067/976/CWE122_Heap_Based_Buffer_Overflow__cpp_CWE193_char_memmove_41.cpp"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 380 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "SARD/000/067/976/CWE122_Heap_Based_Buffer_Overflow__cpp_CWE193_char_memmove_41.cpp" 2
# 26 "SARD/000/067/976/CWE122_Heap_Based_Buffer_Overflow__cpp_CWE193_char_memmove_41.cpp"
namespace CWE122_Heap_Based_Buffer_Overflow__cpp_CWE193_char_memmove_41
{



void badSink(char * data)
{
    {
        char source[10+1] = "AAAAAAAAAA";


        memmove(data, source, (strlen(source) + 1) * sizeof(char));
        printLine(data);
        delete [] data;
    }
}

void bad()
{
    char * data;
    data = NULL;

    data = new char[10];
    badSink(data);
}
# 85 "SARD/000/067/976/CWE122_Heap_Based_Buffer_Overflow__cpp_CWE193_char_memmove_41.cpp"
}
