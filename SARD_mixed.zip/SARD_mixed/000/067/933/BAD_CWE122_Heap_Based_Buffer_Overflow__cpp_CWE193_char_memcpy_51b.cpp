# 1 "SARD/000/067/933/CWE122_Heap_Based_Buffer_Overflow__cpp_CWE193_char_memcpy_51b.cpp"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 380 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "SARD/000/067/933/CWE122_Heap_Based_Buffer_Overflow__cpp_CWE193_char_memcpy_51b.cpp" 2
# 26 "SARD/000/067/933/CWE122_Heap_Based_Buffer_Overflow__cpp_CWE193_char_memcpy_51b.cpp"
namespace CWE122_Heap_Based_Buffer_Overflow__cpp_CWE193_char_memcpy_51
{





void badSink(char * data)
{
    {
        char source[10+1] = "AAAAAAAAAA";


        memcpy(data, source, (strlen(source) + 1) * sizeof(char));
        printLine(data);
        delete [] data;
    }
}
# 64 "SARD/000/067/933/CWE122_Heap_Based_Buffer_Overflow__cpp_CWE193_char_memcpy_51b.cpp"
}
