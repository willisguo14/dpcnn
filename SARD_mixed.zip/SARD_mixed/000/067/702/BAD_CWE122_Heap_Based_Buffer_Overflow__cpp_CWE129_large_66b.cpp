# 1 "SARD/000/067/702/CWE122_Heap_Based_Buffer_Overflow__cpp_CWE129_large_66b.cpp"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 380 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "SARD/000/067/702/CWE122_Heap_Based_Buffer_Overflow__cpp_CWE129_large_66b.cpp" 2
# 20 "SARD/000/067/702/CWE122_Heap_Based_Buffer_Overflow__cpp_CWE129_large_66b.cpp"
namespace CWE122_Heap_Based_Buffer_Overflow__cpp_CWE129_large_66
{



void badSink(int dataArray[])
{

    int data = dataArray[2];
    {
        int i;
        int * buffer = new int[10];

        for (i = 0; i < 10; i++)
        {
            buffer[i] = 0;
        }


        if (data >= 0)
        {
            buffer[data] = 1;

            for(i = 0; i < 10; i++)
            {
                printIntLine(buffer[i]);
            }
        }
        else
        {
            printLine("ERROR: Array index is negative.");
        }
        delete[] buffer;
    }
}
# 123 "SARD/000/067/702/CWE122_Heap_Based_Buffer_Overflow__cpp_CWE129_large_66b.cpp"
}
