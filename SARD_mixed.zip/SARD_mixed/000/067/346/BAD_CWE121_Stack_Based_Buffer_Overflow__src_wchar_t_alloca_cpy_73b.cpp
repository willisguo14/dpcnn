# 1 "SARD/000/067/346/CWE121_Stack_Based_Buffer_Overflow__src_wchar_t_alloca_cpy_73b.cpp"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 380 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "SARD/000/067/346/CWE121_Stack_Based_Buffer_Overflow__src_wchar_t_alloca_cpy_73b.cpp" 2
# 22 "SARD/000/067/346/CWE121_Stack_Based_Buffer_Overflow__src_wchar_t_alloca_cpy_73b.cpp"
using namespace std;

namespace CWE121_Stack_Based_Buffer_Overflow__src_wchar_t_alloca_cpy_73
{



void badSink(list<wchar_t *> dataList)
{

    wchar_t * data = dataList.back();
    {
        wchar_t dest[50] = L"";

        wcscpy(dest, data);
        printWLine(data);
    }
}
# 59 "SARD/000/067/346/CWE121_Stack_Based_Buffer_Overflow__src_wchar_t_alloca_cpy_73b.cpp"
}
