# 1 "SARD/000/067/006/CWE121_Stack_Based_Buffer_Overflow__placement_new_alloca_41.cpp"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 380 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "SARD/000/067/006/CWE121_Stack_Based_Buffer_Overflow__placement_new_alloca_41.cpp" 2
# 20 "SARD/000/067/006/CWE121_Stack_Based_Buffer_Overflow__placement_new_alloca_41.cpp"
namespace CWE121_Stack_Based_Buffer_Overflow__placement_new_alloca_41
{



static void badSink(char * data)
{
    {





        TwoIntsClass * classTwo = new(data) TwoIntsClass;

        classTwo->intOne = 5;
        classTwo->intTwo = 10;
        printIntLine(classTwo->intOne);

    }
}

void bad()
{
    char * data;
    char * dataBadBuffer = (char *)ALLOCA(sizeof(OneIntClass));
    char * dataGoodBuffer = (char *)ALLOCA(sizeof(TwoIntsClass));

    data = dataBadBuffer;
    badSink(data);
}
# 118 "SARD/000/067/006/CWE121_Stack_Based_Buffer_Overflow__placement_new_alloca_41.cpp"
}
