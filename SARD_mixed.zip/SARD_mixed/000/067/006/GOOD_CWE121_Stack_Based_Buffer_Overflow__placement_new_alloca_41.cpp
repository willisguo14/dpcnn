# 1 "SARD/000/067/006/CWE121_Stack_Based_Buffer_Overflow__placement_new_alloca_41.cpp"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 380 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "SARD/000/067/006/CWE121_Stack_Based_Buffer_Overflow__placement_new_alloca_41.cpp" 2
# 20 "SARD/000/067/006/CWE121_Stack_Based_Buffer_Overflow__placement_new_alloca_41.cpp"
namespace CWE121_Stack_Based_Buffer_Overflow__placement_new_alloca_41
{
# 57 "SARD/000/067/006/CWE121_Stack_Based_Buffer_Overflow__placement_new_alloca_41.cpp"
static void goodG2BSink(char * data)
{
    {





        TwoIntsClass * classTwo = new(data) TwoIntsClass;

        classTwo->intOne = 5;
        classTwo->intTwo = 10;
        printIntLine(classTwo->intOne);

    }
}

static void goodG2B()
{
    char * data;
    char * dataBadBuffer = (char *)ALLOCA(sizeof(OneIntClass));
    char * dataGoodBuffer = (char *)ALLOCA(sizeof(TwoIntsClass));

    data = dataGoodBuffer;
    goodG2BSink(data);
}


static void goodB2GSink(char * data)
{
    {





        OneIntClass * classOne = new(data) OneIntClass;

        classOne->intOne = 5;
        printIntLine(classOne->intOne);
    }
}

static void goodB2G()
{
    char * data;
    char * dataBadBuffer = (char *)ALLOCA(sizeof(OneIntClass));
    char * dataGoodBuffer = (char *)ALLOCA(sizeof(TwoIntsClass));

    data = dataBadBuffer;
    goodB2GSink(data);
}

void good()
{
    goodG2B();
    goodB2G();
}



}
