# 1 "SARD/000/067/815/CWE122_Heap_Based_Buffer_Overflow__cpp_CWE193_char_cpy_08.cpp"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 380 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "SARD/000/067/815/CWE122_Heap_Based_Buffer_Overflow__cpp_CWE193_char_cpy_08.cpp" 2
# 29 "SARD/000/067/815/CWE122_Heap_Based_Buffer_Overflow__cpp_CWE193_char_cpy_08.cpp"
static int staticReturnsTrue()
{
    return 1;
}

static int staticReturnsFalse()
{
    return 0;
}

namespace CWE122_Heap_Based_Buffer_Overflow__cpp_CWE193_char_cpy_08
{



void bad()
{
    char * data;
    data = NULL;
    if(staticReturnsTrue())
    {

        data = new char[10];
    }
    {
        char source[10+1] = "AAAAAAAAAA";

        strcpy(data, source);
        printLine(data);
        delete [] data;
    }
}
# 117 "SARD/000/067/815/CWE122_Heap_Based_Buffer_Overflow__cpp_CWE193_char_cpy_08.cpp"
}
