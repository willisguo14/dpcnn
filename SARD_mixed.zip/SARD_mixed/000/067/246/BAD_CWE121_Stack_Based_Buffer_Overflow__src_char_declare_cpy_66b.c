# 1 "SARD/000/067/246/CWE121_Stack_Based_Buffer_Overflow__src_char_declare_cpy_66b.c"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 367 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "SARD/000/067/246/CWE121_Stack_Based_Buffer_Overflow__src_char_declare_cpy_66b.c" 2
# 23 "SARD/000/067/246/CWE121_Stack_Based_Buffer_Overflow__src_char_declare_cpy_66b.c"
void CWE121_Stack_Based_Buffer_Overflow__src_char_declare_cpy_66b_badSink(char * dataArray[])
{

    char * data = dataArray[2];
    {
        char dest[50] = "";

        strcpy(dest, data);
        printLine(data);
    }
}
