# 1 "SARD/000/067/986/CWE122_Heap_Based_Buffer_Overflow__cpp_CWE193_char_memmove_62a.cpp"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 380 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "SARD/000/067/986/CWE122_Heap_Based_Buffer_Overflow__cpp_CWE193_char_memmove_62a.cpp" 2
# 26 "SARD/000/067/986/CWE122_Heap_Based_Buffer_Overflow__cpp_CWE193_char_memmove_62a.cpp"
namespace CWE122_Heap_Based_Buffer_Overflow__cpp_CWE193_char_memmove_62
{
# 54 "SARD/000/067/986/CWE122_Heap_Based_Buffer_Overflow__cpp_CWE193_char_memmove_62a.cpp"
void goodG2BSource(char * &data);

static void goodG2B()
{
    char * data;
    data = NULL;
    goodG2BSource(data);
    {
        char source[10+1] = "AAAAAAAAAA";


        memmove(data, source, (strlen(source) + 1) * sizeof(char));
        printLine(data);
        delete [] data;
    }
}

void good()
{
    goodG2B();
}



}
