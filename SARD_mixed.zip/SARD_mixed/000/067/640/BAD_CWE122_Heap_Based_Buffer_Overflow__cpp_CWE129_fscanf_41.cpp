# 1 "SARD/000/067/640/CWE122_Heap_Based_Buffer_Overflow__cpp_CWE129_fscanf_41.cpp"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 380 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "SARD/000/067/640/CWE122_Heap_Based_Buffer_Overflow__cpp_CWE129_fscanf_41.cpp" 2
# 20 "SARD/000/067/640/CWE122_Heap_Based_Buffer_Overflow__cpp_CWE129_fscanf_41.cpp"
namespace CWE122_Heap_Based_Buffer_Overflow__cpp_CWE129_fscanf_41
{



static void badSink(int data)
{
    {
        int i;
        int * buffer = new int[10];

        for (i = 0; i < 10; i++)
        {
            buffer[i] = 0;
        }


        if (data >= 0)
        {
            buffer[data] = 1;

            for(i = 0; i < 10; i++)
            {
                printIntLine(buffer[i]);
            }
        }
        else
        {
            printLine("ERROR: Array index is negative.");
        }
        delete[] buffer;
    }
}

void bad()
{
    int data;

    data = -1;

    fscanf(stdin, "%d", &data);
    badSink(data);
}
# 156 "SARD/000/067/640/CWE122_Heap_Based_Buffer_Overflow__cpp_CWE129_fscanf_41.cpp"
}
