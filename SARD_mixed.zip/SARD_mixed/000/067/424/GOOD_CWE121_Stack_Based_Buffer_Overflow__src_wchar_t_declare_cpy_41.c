# 1 "SARD/000/067/424/CWE121_Stack_Based_Buffer_Overflow__src_wchar_t_declare_cpy_41.c"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 367 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "SARD/000/067/424/CWE121_Stack_Based_Buffer_Overflow__src_wchar_t_declare_cpy_41.c" 2
# 48 "SARD/000/067/424/CWE121_Stack_Based_Buffer_Overflow__src_wchar_t_declare_cpy_41.c"
void CWE121_Stack_Based_Buffer_Overflow__src_wchar_t_declare_cpy_41_goodG2BSink(wchar_t * data)
{
    {
        wchar_t dest[50] = L"";

        wcscpy(dest, data);
        printWLine(data);
    }
}


static void goodG2B()
{
    wchar_t * data;
    wchar_t dataBuffer[100];
    data = dataBuffer;

    wmemset(data, L'A', 50-1);
    data[50-1] = L'\0';
    CWE121_Stack_Based_Buffer_Overflow__src_wchar_t_declare_cpy_41_goodG2BSink(data);
}

void CWE121_Stack_Based_Buffer_Overflow__src_wchar_t_declare_cpy_41_good()
{
    goodG2B();
}
