# 1 "SARD/000/067/312/CWE121_Stack_Based_Buffer_Overflow__src_wchar_t_alloca_cpy_09.c"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 367 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "SARD/000/067/312/CWE121_Stack_Based_Buffer_Overflow__src_wchar_t_alloca_cpy_09.c" 2
# 23 "SARD/000/067/312/CWE121_Stack_Based_Buffer_Overflow__src_wchar_t_alloca_cpy_09.c"
void CWE121_Stack_Based_Buffer_Overflow__src_wchar_t_alloca_cpy_09_bad()
{
    wchar_t * data;
    wchar_t * dataBuffer = (wchar_t *)ALLOCA(100*sizeof(wchar_t));
    data = dataBuffer;
    if(GLOBAL_CONST_TRUE)
    {

        wmemset(data, L'A', 100-1);
        data[100-1] = L'\0';
    }
    {
        wchar_t dest[50] = L"";

        wcscpy(dest, data);
        printWLine(data);
    }
}
