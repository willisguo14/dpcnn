# 1 "SARD/000/067/186/CWE121_Stack_Based_Buffer_Overflow__src_char_declare_cat_43.cpp"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 380 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "SARD/000/067/186/CWE121_Stack_Based_Buffer_Overflow__src_char_declare_cat_43.cpp" 2
# 21 "SARD/000/067/186/CWE121_Stack_Based_Buffer_Overflow__src_char_declare_cat_43.cpp"
namespace CWE121_Stack_Based_Buffer_Overflow__src_char_declare_cat_43
{
# 52 "SARD/000/067/186/CWE121_Stack_Based_Buffer_Overflow__src_char_declare_cat_43.cpp"
static void goodG2BSource(char * &data)
{

    memset(data, 'A', 50-1);
    data[50-1] = '\0';
}

static void goodG2B()
{
    char * data;
    char dataBuffer[100];
    data = dataBuffer;
    goodG2BSource(data);
    {
        char dest[50] = "";

        strcat(dest, data);
        printLine(data);
    }
}

void good()
{
    goodG2B();
}



}
