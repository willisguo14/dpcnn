# 1 "SARD/000/067/041/CWE121_Stack_Based_Buffer_Overflow__placement_new_declare_18.cpp"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 380 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "SARD/000/067/041/CWE121_Stack_Based_Buffer_Overflow__placement_new_declare_18.cpp" 2
# 19 "SARD/000/067/041/CWE121_Stack_Based_Buffer_Overflow__placement_new_declare_18.cpp"
namespace CWE121_Stack_Based_Buffer_Overflow__placement_new_declare_18
{
# 55 "SARD/000/067/041/CWE121_Stack_Based_Buffer_Overflow__placement_new_declare_18.cpp"
static void goodB2G()
{
    char * data;
    char dataBadBuffer[sizeof(OneIntClass)];
    char dataGoodBuffer[sizeof(TwoIntsClass)];
    goto source;
source:

    data = dataBadBuffer;
    goto sink;
sink:
    {





        OneIntClass * classOne = new(data) OneIntClass;

        classOne->intOne = 5;
        printIntLine(classOne->intOne);
    }
}


static void goodG2B()
{
    char * data;
    char dataBadBuffer[sizeof(OneIntClass)];
    char dataGoodBuffer[sizeof(TwoIntsClass)];
    goto source;
source:

    data = dataGoodBuffer;
    goto sink;
sink:
    {





        TwoIntsClass * classTwo = new(data) TwoIntsClass;

        classTwo->intOne = 5;
        classTwo->intTwo = 10;
        printIntLine(classTwo->intOne);

    }
}

void good()
{
    goodB2G();
    goodG2B();
}



}
