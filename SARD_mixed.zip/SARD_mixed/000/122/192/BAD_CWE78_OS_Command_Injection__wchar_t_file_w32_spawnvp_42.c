# 1 "SARD/000/122/192/CWE78_OS_Command_Injection__wchar_t_file_w32_spawnvp_42.c"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 367 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "SARD/000/122/192/CWE78_OS_Command_Injection__wchar_t_file_w32_spawnvp_42.c" 2
# 46 "SARD/000/122/192/CWE78_OS_Command_Injection__wchar_t_file_w32_spawnvp_42.c"
static wchar_t * badSource(wchar_t * data)
{
    {

        size_t dataLen = wcslen(data);
        FILE * pFile;

        if (100-dataLen > 1)
        {
            pFile = fopen("/tmp/file.txt", "r");
            if (pFile != NULL)
            {

                if (fgetws(data+dataLen, (int)(100-dataLen), pFile) == NULL)
                {
                    printLine("fgetws() failed");

                    data[dataLen] = L'\0';
                }
                fclose(pFile);
            }
        }
    }
    return data;
}

void CWE78_OS_Command_Injection__wchar_t_file_w32_spawnvp_42_bad()
{
    wchar_t * data;
    wchar_t dataBuffer[100] = L"";
    data = dataBuffer;
    data = badSource(data);
    {
        wchar_t *args[] = {L"/bin/sh", L"ls", L"-la", data, NULL};



        _wspawnvp(_P_WAIT, L"sh", args);
    }
}
