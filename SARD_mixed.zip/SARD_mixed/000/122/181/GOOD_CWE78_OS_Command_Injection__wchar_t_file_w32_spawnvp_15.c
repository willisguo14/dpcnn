# 1 "SARD/000/122/181/CWE78_OS_Command_Injection__wchar_t_file_w32_spawnvp_15.c"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 367 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "SARD/000/122/181/CWE78_OS_Command_Injection__wchar_t_file_w32_spawnvp_15.c" 2
# 95 "SARD/000/122/181/CWE78_OS_Command_Injection__wchar_t_file_w32_spawnvp_15.c"
static void goodG2B1()
{
    wchar_t * data;
    wchar_t dataBuffer[100] = L"";
    data = dataBuffer;
    switch(5)
    {
    case 6:

        printLine("Benign, fixed string");
        break;
    default:

        wcscat(data, L"*.*");
        break;
    }
    {
        wchar_t *args[] = {L"/bin/sh", L"ls", L"-la", data, NULL};



        _wspawnvp(_P_WAIT, L"sh", args);
    }
}


static void goodG2B2()
{
    wchar_t * data;
    wchar_t dataBuffer[100] = L"";
    data = dataBuffer;
    switch(6)
    {
    case 6:

        wcscat(data, L"*.*");
        break;
    default:

        printLine("Benign, fixed string");
        break;
    }
    {
        wchar_t *args[] = {L"/bin/sh", L"ls", L"-la", data, NULL};



        _wspawnvp(_P_WAIT, L"sh", args);
    }
}

void CWE78_OS_Command_Injection__wchar_t_file_w32_spawnvp_15_good()
{
    goodG2B1();
    goodG2B2();
}
