# 1 "SARD/000/122/545/CWE78_OS_Command_Injection__wchar_t_listen_socket_w32spawnl_73b.cpp"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 380 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "SARD/000/122/545/CWE78_OS_Command_Injection__wchar_t_listen_socket_w32spawnl_73b.cpp" 2
# 39 "SARD/000/122/545/CWE78_OS_Command_Injection__wchar_t_listen_socket_w32spawnl_73b.cpp"
using namespace std;

namespace CWE78_OS_Command_Injection__wchar_t_listen_socket_w32spawnl_73
{
# 60 "SARD/000/122/545/CWE78_OS_Command_Injection__wchar_t_listen_socket_w32spawnl_73b.cpp"
void goodG2BSink(list<wchar_t *> dataList)
{
    wchar_t * data = dataList.back();


    _wspawnl(_P_WAIT, L"/bin/sh", L"/bin/sh", L"ls", L"-la", data, NULL);
}



}
