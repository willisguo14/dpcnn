# 1 "SARD/000/122/385/CWE78_OS_Command_Injection__wchar_t_listen_socket_popen_43.cpp"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 380 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "SARD/000/122/385/CWE78_OS_Command_Injection__wchar_t_listen_socket_popen_43.cpp" 2
# 57 "SARD/000/122/385/CWE78_OS_Command_Injection__wchar_t_listen_socket_popen_43.cpp"
namespace CWE78_OS_Command_Injection__wchar_t_listen_socket_popen_43
{
# 167 "SARD/000/122/385/CWE78_OS_Command_Injection__wchar_t_listen_socket_popen_43.cpp"
static void goodG2BSource(wchar_t * &data)
{

    wcscat(data, L"*.*");
}

static void goodG2B()
{
    wchar_t * data;
    wchar_t data_buf[100] = L"/bin/sh ls -la ";
    data = data_buf;
    goodG2BSource(data);
    {
        FILE *pipe;

        pipe = popen(data, L"wb");
        if (pipe != NULL)
        {
            pclose(pipe);
        }
    }
}

void good()
{
    goodG2B();
}



}
