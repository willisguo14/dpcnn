# 1 "SARD/000/122/393/CWE78_OS_Command_Injection__wchar_t_listen_socket_popen_62a.cpp"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 380 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "SARD/000/122/393/CWE78_OS_Command_Injection__wchar_t_listen_socket_popen_62a.cpp" 2
# 37 "SARD/000/122/393/CWE78_OS_Command_Injection__wchar_t_listen_socket_popen_62a.cpp"
namespace CWE78_OS_Command_Injection__wchar_t_listen_socket_popen_62
{
# 67 "SARD/000/122/393/CWE78_OS_Command_Injection__wchar_t_listen_socket_popen_62a.cpp"
void goodG2BSource(wchar_t * &data);

static void goodG2B()
{
    wchar_t * data;
    wchar_t data_buf[100] = L"/bin/sh ls -la ";
    data = data_buf;
    goodG2BSource(data);
    {
        FILE *pipe;

        pipe = popen(data, L"wb");
        if (pipe != NULL)
        {
            pclose(pipe);
        }
    }
}

void good()
{
    goodG2B();
}



}
