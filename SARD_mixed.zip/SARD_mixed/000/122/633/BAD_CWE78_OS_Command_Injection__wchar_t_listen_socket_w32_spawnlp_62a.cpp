# 1 "SARD/000/122/633/CWE78_OS_Command_Injection__wchar_t_listen_socket_w32_spawnlp_62a.cpp"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 380 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "SARD/000/122/633/CWE78_OS_Command_Injection__wchar_t_listen_socket_w32_spawnlp_62a.cpp" 2
# 38 "SARD/000/122/633/CWE78_OS_Command_Injection__wchar_t_listen_socket_w32_spawnlp_62a.cpp"
namespace CWE78_OS_Command_Injection__wchar_t_listen_socket_w32_spawnlp_62
{




void badSource(wchar_t * &data);

void bad()
{
    wchar_t * data;
    wchar_t dataBuffer[100] = L"";
    data = dataBuffer;
    badSource(data);



    _wspawnlp(_P_WAIT, L"sh", L"sh", L"ls", L"-la", data, NULL);
}
# 84 "SARD/000/122/633/CWE78_OS_Command_Injection__wchar_t_listen_socket_w32_spawnlp_62a.cpp"
}
