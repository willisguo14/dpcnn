# 1 "SARD/000/122/322/CWE78_OS_Command_Injection__wchar_t_listen_socket_execlp_12.c"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 367 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "SARD/000/122/322/CWE78_OS_Command_Injection__wchar_t_listen_socket_execlp_12.c" 2
# 169 "SARD/000/122/322/CWE78_OS_Command_Injection__wchar_t_listen_socket_execlp_12.c"
static void goodG2B()
{
    wchar_t * data;
    wchar_t dataBuffer[100] = L"";
    data = dataBuffer;
    if(globalReturnsTrueOrFalse())
    {

        wcscat(data, L"*.*");
    }
    else
    {

        wcscat(data, L"*.*");
    }



    execlp(L"sh", L"sh", L"ls", L"-la", data, NULL);
}

void CWE78_OS_Command_Injection__wchar_t_listen_socket_execlp_12_good()
{
    goodG2B();
}
