# 1 "SARD/000/122/736/CWE78_OS_Command_Injection__wchar_t_listen_socket_w32_spawnvp_72b.cpp"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 380 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "SARD/000/122/736/CWE78_OS_Command_Injection__wchar_t_listen_socket_w32_spawnvp_72b.cpp" 2
# 39 "SARD/000/122/736/CWE78_OS_Command_Injection__wchar_t_listen_socket_w32_spawnvp_72b.cpp"
using namespace std;

namespace CWE78_OS_Command_Injection__wchar_t_listen_socket_w32_spawnvp_72
{
# 64 "SARD/000/122/736/CWE78_OS_Command_Injection__wchar_t_listen_socket_w32_spawnvp_72b.cpp"
void goodG2BSink(vector<wchar_t *> dataVector)
{
    wchar_t * data = dataVector[2];
    {
        wchar_t *args[] = {L"/bin/sh", L"ls", L"-la", data, NULL};



        _wspawnvp(_P_WAIT, L"sh", args);
    }
}



}
