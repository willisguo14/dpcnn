# 1 "SARD/000/122/893/CWE90_LDAP_Injection__w32_char_connect_socket_83_bad.cpp"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 380 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "SARD/000/122/893/CWE90_LDAP_Injection__w32_char_connect_socket_83_bad.cpp" 2

