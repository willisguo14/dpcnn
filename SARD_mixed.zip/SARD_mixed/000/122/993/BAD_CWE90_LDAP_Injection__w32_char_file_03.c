# 1 "SARD/000/122/993/CWE90_LDAP_Injection__w32_char_file_03.c"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 367 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "SARD/000/122/993/CWE90_LDAP_Injection__w32_char_file_03.c" 2
# 28 "SARD/000/122/993/CWE90_LDAP_Injection__w32_char_file_03.c"
#pragma comment(lib, "wldap32")



void CWE90_LDAP_Injection__w32_char_file_03_bad()
{
    char * data;
    char dataBuffer[256] = "";
    data = dataBuffer;
    if(5==5)
    {
        {

            size_t dataLen = strlen(data);
            FILE * pFile;

            if (256-dataLen > 1)
            {
                pFile = fopen("/tmp/file.txt", "r");
                if (pFile != NULL)
                {

                    if (fgets(data+dataLen, (int)(256-dataLen), pFile) == NULL)
                    {
                        printLine("fgets() failed");

                        data[dataLen] = '\0';
                    }
                    fclose(pFile);
                }
            }
        }
    }
    {
        LDAP* pLdapConnection = NULL;
        ULONG connectSuccess = 0L;
        ULONG searchSuccess = 0L;
        LDAPMessage *pMessage = NULL;
        char filter[256];

        _snprintf(filter, 256-1, "(cn=%s)", data);
        pLdapConnection = ldap_initA("localhost", LDAP_PORT);
        if (pLdapConnection == NULL)
        {
            printLine("Initialization failed");
            exit(1);
        }
        connectSuccess = ldap_connect(pLdapConnection, NULL);
        if (connectSuccess != LDAP_SUCCESS)
        {
            printLine("Connection failed");
            exit(1);
        }
        searchSuccess = ldap_search_ext_sA(
                            pLdapConnection,
                            "base",
                            LDAP_SCOPE_SUBTREE,
                            filter,
                            NULL,
                            0,
                            NULL,
                            NULL,
                            LDAP_NO_LIMIT,
                            LDAP_NO_LIMIT,
                            &pMessage);
        if (searchSuccess != LDAP_SUCCESS)
        {
            printLine("Search failed");
            if (pMessage != NULL)
            {
                ldap_msgfree(pMessage);
            }
            exit(1);
        }


        if (pMessage != NULL)
        {
            ldap_msgfree(pMessage);
        }

        ldap_unbind(pLdapConnection);
    }
}
