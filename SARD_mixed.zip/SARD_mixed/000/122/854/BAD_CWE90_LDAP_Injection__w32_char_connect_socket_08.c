# 1 "SARD/000/122/854/CWE90_LDAP_Injection__w32_char_connect_socket_08.c"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 367 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "SARD/000/122/854/CWE90_LDAP_Injection__w32_char_connect_socket_08.c" 2
# 42 "SARD/000/122/854/CWE90_LDAP_Injection__w32_char_connect_socket_08.c"
#pragma comment(lib, "wldap32")





static int staticReturnsTrue()
{
    return 1;
}

static int staticReturnsFalse()
{
    return 0;
}



void CWE90_LDAP_Injection__w32_char_connect_socket_08_bad()
{
    char * data;
    char dataBuffer[256] = "";
    data = dataBuffer;
    if(staticReturnsTrue())
    {
        {




            int recvResult;
            struct sockaddr_in service;
            char *replace;
            int connectSocket = -1;
            size_t dataLen = strlen(data);
            do
            {
# 87 "SARD/000/122/854/CWE90_LDAP_Injection__w32_char_connect_socket_08.c"
                connectSocket = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
                if (connectSocket == -1)
                {
                    break;
                }
                memset(&service, 0, sizeof(service));
                service.sin_family = AF_INET;
                service.sin_addr.s_addr = inet_addr("127.0.0.1");
                service.sin_port = htons(27015);
                if (connect(connectSocket, (struct sockaddr*)&service, sizeof(service)) == -1)
                {
                    break;
                }



                recvResult = recv(connectSocket, (char *)(data + dataLen), sizeof(char) * (256 - dataLen - 1), 0);
                if (recvResult == -1 || recvResult == 0)
                {
                    break;
                }

                data[dataLen + recvResult / sizeof(char)] = '\0';

                replace = strchr(data, '\r');
                if (replace)
                {
                    *replace = '\0';
                }
                replace = strchr(data, '\n');
                if (replace)
                {
                    *replace = '\0';
                }
            }
            while (0);
            if (connectSocket != -1)
            {
                close(connectSocket);
            }






        }
    }
    {
        LDAP* pLdapConnection = NULL;
        ULONG connectSuccess = 0L;
        ULONG searchSuccess = 0L;
        LDAPMessage *pMessage = NULL;
        char filter[256];

        _snprintf(filter, 256-1, "(cn=%s)", data);
        pLdapConnection = ldap_initA("localhost", LDAP_PORT);
        if (pLdapConnection == NULL)
        {
            printLine("Initialization failed");
            exit(1);
        }
        connectSuccess = ldap_connect(pLdapConnection, NULL);
        if (connectSuccess != LDAP_SUCCESS)
        {
            printLine("Connection failed");
            exit(1);
        }
        searchSuccess = ldap_search_ext_sA(
                            pLdapConnection,
                            "base",
                            LDAP_SCOPE_SUBTREE,
                            filter,
                            NULL,
                            0,
                            NULL,
                            NULL,
                            LDAP_NO_LIMIT,
                            LDAP_NO_LIMIT,
                            &pMessage);
        if (searchSuccess != LDAP_SUCCESS)
        {
            printLine("Search failed");
            if (pMessage != NULL)
            {
                ldap_msgfree(pMessage);
            }
            exit(1);
        }


        if (pMessage != NULL)
        {
            ldap_msgfree(pMessage);
        }

        ldap_unbind(pLdapConnection);
    }
}
