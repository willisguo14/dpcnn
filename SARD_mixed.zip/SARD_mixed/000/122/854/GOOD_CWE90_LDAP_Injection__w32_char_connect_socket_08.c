# 1 "SARD/000/122/854/CWE90_LDAP_Injection__w32_char_connect_socket_08.c"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 367 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "SARD/000/122/854/CWE90_LDAP_Injection__w32_char_connect_socket_08.c" 2
# 42 "SARD/000/122/854/CWE90_LDAP_Injection__w32_char_connect_socket_08.c"
#pragma comment(lib, "wldap32")





static int staticReturnsTrue()
{
    return 1;
}

static int staticReturnsFalse()
{
    return 0;
}
# 192 "SARD/000/122/854/CWE90_LDAP_Injection__w32_char_connect_socket_08.c"
static void goodG2B1()
{
    char * data;
    char dataBuffer[256] = "";
    data = dataBuffer;
    if(staticReturnsFalse())
    {

        printLine("Benign, fixed string");
    }
    else
    {

        strcat(data, "Doe, XXXXX");
    }
    {
        LDAP* pLdapConnection = NULL;
        ULONG connectSuccess = 0L;
        ULONG searchSuccess = 0L;
        LDAPMessage *pMessage = NULL;
        char filter[256];

        _snprintf(filter, 256-1, "(cn=%s)", data);
        pLdapConnection = ldap_initA("localhost", LDAP_PORT);
        if (pLdapConnection == NULL)
        {
            printLine("Initialization failed");
            exit(1);
        }
        connectSuccess = ldap_connect(pLdapConnection, NULL);
        if (connectSuccess != LDAP_SUCCESS)
        {
            printLine("Connection failed");
            exit(1);
        }
        searchSuccess = ldap_search_ext_sA(
                            pLdapConnection,
                            "base",
                            LDAP_SCOPE_SUBTREE,
                            filter,
                            NULL,
                            0,
                            NULL,
                            NULL,
                            LDAP_NO_LIMIT,
                            LDAP_NO_LIMIT,
                            &pMessage);
        if (searchSuccess != LDAP_SUCCESS)
        {
            printLine("Search failed");
            if (pMessage != NULL)
            {
                ldap_msgfree(pMessage);
            }
            exit(1);
        }


        if (pMessage != NULL)
        {
            ldap_msgfree(pMessage);
        }

        ldap_unbind(pLdapConnection);
    }
}


static void goodG2B2()
{
    char * data;
    char dataBuffer[256] = "";
    data = dataBuffer;
    if(staticReturnsTrue())
    {

        strcat(data, "Doe, XXXXX");
    }
    {
        LDAP* pLdapConnection = NULL;
        ULONG connectSuccess = 0L;
        ULONG searchSuccess = 0L;
        LDAPMessage *pMessage = NULL;
        char filter[256];

        _snprintf(filter, 256-1, "(cn=%s)", data);
        pLdapConnection = ldap_initA("localhost", LDAP_PORT);
        if (pLdapConnection == NULL)
        {
            printLine("Initialization failed");
            exit(1);
        }
        connectSuccess = ldap_connect(pLdapConnection, NULL);
        if (connectSuccess != LDAP_SUCCESS)
        {
            printLine("Connection failed");
            exit(1);
        }
        searchSuccess = ldap_search_ext_sA(
                            pLdapConnection,
                            "base",
                            LDAP_SCOPE_SUBTREE,
                            filter,
                            NULL,
                            0,
                            NULL,
                            NULL,
                            LDAP_NO_LIMIT,
                            LDAP_NO_LIMIT,
                            &pMessage);
        if (searchSuccess != LDAP_SUCCESS)
        {
            printLine("Search failed");
            if (pMessage != NULL)
            {
                ldap_msgfree(pMessage);
            }
            exit(1);
        }


        if (pMessage != NULL)
        {
            ldap_msgfree(pMessage);
        }

        ldap_unbind(pLdapConnection);
    }
}

void CWE90_LDAP_Injection__w32_char_connect_socket_08_good()
{
    goodG2B1();
    goodG2B2();
}
