# 1 "SARD/000/122/403/CWE78_OS_Command_Injection__wchar_t_listen_socket_popen_81_bad.cpp"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 380 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "SARD/000/122/403/CWE78_OS_Command_Injection__wchar_t_listen_socket_popen_81_bad.cpp" 2
# 30 "SARD/000/122/403/CWE78_OS_Command_Injection__wchar_t_listen_socket_popen_81_bad.cpp"
namespace CWE78_OS_Command_Injection__wchar_t_listen_socket_popen_81
{

void CWE78_OS_Command_Injection__wchar_t_listen_socket_popen_81_bad::action(wchar_t * data) const
{
    {
        FILE *pipe;

        pipe = popen(data, L"wb");
        if (pipe != NULL)
        {
            pclose(pipe);
        }
    }
}

}
