# 1 "SARD/000/122/093/CWE78_OS_Command_Injection__wchar_t_file_w32_spawnlp_33.cpp"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 380 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "SARD/000/122/093/CWE78_OS_Command_Injection__wchar_t_file_w32_spawnlp_33.cpp" 2
# 44 "SARD/000/122/093/CWE78_OS_Command_Injection__wchar_t_file_w32_spawnlp_33.cpp"
namespace CWE78_OS_Command_Injection__wchar_t_file_w32_spawnlp_33
{
# 90 "SARD/000/122/093/CWE78_OS_Command_Injection__wchar_t_file_w32_spawnlp_33.cpp"
static void goodG2B()
{
    wchar_t * data;
    wchar_t * &dataRef = data;
    wchar_t dataBuffer[100] = L"";
    data = dataBuffer;

    wcscat(data, L"*.*");
    {
        wchar_t * data = dataRef;



        _wspawnlp(_P_WAIT, L"sh", L"sh", L"ls", L"-la", data, NULL);
    }
}

void good()
{
    goodG2B();
}



}
