# 1 "SARD/000/122/282/CWE78_OS_Command_Injection__wchar_t_listen_socket_execl_22a.c"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 367 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "SARD/000/122/282/CWE78_OS_Command_Injection__wchar_t_listen_socket_execl_22a.c" 2
# 67 "SARD/000/122/282/CWE78_OS_Command_Injection__wchar_t_listen_socket_execl_22a.c"
int CWE78_OS_Command_Injection__wchar_t_listen_socket_execl_22_goodG2B1Global = 0;
int CWE78_OS_Command_Injection__wchar_t_listen_socket_execl_22_goodG2B2Global = 0;


wchar_t * CWE78_OS_Command_Injection__wchar_t_listen_socket_execl_22_goodG2B1Source(wchar_t * data);

static void goodG2B1()
{
    wchar_t * data;
    wchar_t dataBuffer[100] = L"";
    data = dataBuffer;
    CWE78_OS_Command_Injection__wchar_t_listen_socket_execl_22_goodG2B1Global = 0;
    data = CWE78_OS_Command_Injection__wchar_t_listen_socket_execl_22_goodG2B1Source(data);


    execl(L"/bin/sh", L"/bin/sh", L"ls", L"-la", data, NULL);
}


wchar_t * CWE78_OS_Command_Injection__wchar_t_listen_socket_execl_22_goodG2B2Source(wchar_t * data);

static void goodG2B2()
{
    wchar_t * data;
    wchar_t dataBuffer[100] = L"";
    data = dataBuffer;
    CWE78_OS_Command_Injection__wchar_t_listen_socket_execl_22_goodG2B2Global = 1;
    data = CWE78_OS_Command_Injection__wchar_t_listen_socket_execl_22_goodG2B2Source(data);


    execl(L"/bin/sh", L"/bin/sh", L"ls", L"-la", data, NULL);
}

void CWE78_OS_Command_Injection__wchar_t_listen_socket_execl_22_good()
{
    goodG2B1();
    goodG2B2();
}
