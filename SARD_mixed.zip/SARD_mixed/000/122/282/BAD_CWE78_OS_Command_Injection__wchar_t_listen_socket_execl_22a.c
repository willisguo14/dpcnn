# 1 "SARD/000/122/282/CWE78_OS_Command_Injection__wchar_t_listen_socket_execl_22a.c"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 367 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "SARD/000/122/282/CWE78_OS_Command_Injection__wchar_t_listen_socket_execl_22a.c" 2
# 46 "SARD/000/122/282/CWE78_OS_Command_Injection__wchar_t_listen_socket_execl_22a.c"
int CWE78_OS_Command_Injection__wchar_t_listen_socket_execl_22_badGlobal = 0;

wchar_t * CWE78_OS_Command_Injection__wchar_t_listen_socket_execl_22_badSource(wchar_t * data);

void CWE78_OS_Command_Injection__wchar_t_listen_socket_execl_22_bad()
{
    wchar_t * data;
    wchar_t dataBuffer[100] = L"";
    data = dataBuffer;
    CWE78_OS_Command_Injection__wchar_t_listen_socket_execl_22_badGlobal = 1;
    data = CWE78_OS_Command_Injection__wchar_t_listen_socket_execl_22_badSource(data);


    execl(L"/bin/sh", L"/bin/sh", L"ls", L"-la", data, NULL);
}
