# 1 "SARD/000/122/481/CWE78_OS_Command_Injection__wchar_t_listen_socket_w32_execvp_43.cpp"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 380 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "SARD/000/122/481/CWE78_OS_Command_Injection__wchar_t_listen_socket_w32_execvp_43.cpp" 2
# 59 "SARD/000/122/481/CWE78_OS_Command_Injection__wchar_t_listen_socket_w32_execvp_43.cpp"
namespace CWE78_OS_Command_Injection__wchar_t_listen_socket_w32_execvp_43
{
# 167 "SARD/000/122/481/CWE78_OS_Command_Injection__wchar_t_listen_socket_w32_execvp_43.cpp"
static void goodG2BSource(wchar_t * &data)
{

    wcscat(data, L"*.*");
}

static void goodG2B()
{
    wchar_t * data;
    wchar_t dataBuffer[100] = L"";
    data = dataBuffer;
    goodG2BSource(data);
    {
        wchar_t *args[] = {L"/bin/sh", L"ls", L"-la", data, NULL};



        _wexecvp(L"sh", args);
    }
}

void good()
{
    goodG2B();
}



}
