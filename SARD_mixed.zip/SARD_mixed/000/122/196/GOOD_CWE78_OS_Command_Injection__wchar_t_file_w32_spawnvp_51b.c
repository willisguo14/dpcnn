# 1 "SARD/000/122/196/CWE78_OS_Command_Injection__wchar_t_file_w32_spawnvp_51b.c"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 367 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "SARD/000/122/196/CWE78_OS_Command_Injection__wchar_t_file_w32_spawnvp_51b.c" 2
# 64 "SARD/000/122/196/CWE78_OS_Command_Injection__wchar_t_file_w32_spawnvp_51b.c"
void CWE78_OS_Command_Injection__wchar_t_file_w32_spawnvp_51b_goodG2BSink(wchar_t * data)
{
    {
        wchar_t *args[] = {L"/bin/sh", L"ls", L"-la", data, NULL};



        _wspawnvp(_P_WAIT, L"sh", args);
    }
}
