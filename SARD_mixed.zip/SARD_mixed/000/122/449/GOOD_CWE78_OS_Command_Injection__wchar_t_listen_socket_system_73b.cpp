# 1 "SARD/000/122/449/CWE78_OS_Command_Injection__wchar_t_listen_socket_system_73b.cpp"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 380 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "SARD/000/122/449/CWE78_OS_Command_Injection__wchar_t_listen_socket_system_73b.cpp" 2
# 35 "SARD/000/122/449/CWE78_OS_Command_Injection__wchar_t_listen_socket_system_73b.cpp"
using namespace std;

namespace CWE78_OS_Command_Injection__wchar_t_listen_socket_system_73
{
# 59 "SARD/000/122/449/CWE78_OS_Command_Injection__wchar_t_listen_socket_system_73b.cpp"
void goodG2BSink(list<wchar_t *> dataList)
{
    wchar_t * data = dataList.back();

    if (system(data) <= 0)
    {
        printLine("command execution failed!");
        exit(1);
    }
}



}
