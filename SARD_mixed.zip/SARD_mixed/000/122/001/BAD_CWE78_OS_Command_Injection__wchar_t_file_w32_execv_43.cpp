# 1 "SARD/000/122/001/CWE78_OS_Command_Injection__wchar_t_file_w32_execv_43.cpp"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 380 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "SARD/000/122/001/CWE78_OS_Command_Injection__wchar_t_file_w32_execv_43.cpp" 2
# 45 "SARD/000/122/001/CWE78_OS_Command_Injection__wchar_t_file_w32_execv_43.cpp"
namespace CWE78_OS_Command_Injection__wchar_t_file_w32_execv_43
{



static void badSource(wchar_t * &data)
{
    {

        size_t dataLen = wcslen(data);
        FILE * pFile;

        if (100-dataLen > 1)
        {
            pFile = fopen("/tmp/file.txt", "r");
            if (pFile != NULL)
            {

                if (fgetws(data+dataLen, (int)(100-dataLen), pFile) == NULL)
                {
                    printLine("fgetws() failed");

                    data[dataLen] = L'\0';
                }
                fclose(pFile);
            }
        }
    }
}

void bad()
{
    wchar_t * data;
    wchar_t dataBuffer[100] = L"";
    data = dataBuffer;
    badSource(data);
    {
        wchar_t *args[] = {L"/bin/sh", L"ls", L"-la", data, NULL};


        _wexecv(L"/bin/sh", args);
    }
}
# 121 "SARD/000/122/001/CWE78_OS_Command_Injection__wchar_t_file_w32_execv_43.cpp"
}
