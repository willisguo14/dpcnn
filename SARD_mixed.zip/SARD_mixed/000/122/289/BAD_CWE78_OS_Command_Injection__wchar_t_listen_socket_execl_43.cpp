# 1 "SARD/000/122/289/CWE78_OS_Command_Injection__wchar_t_listen_socket_execl_43.cpp"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 380 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "SARD/000/122/289/CWE78_OS_Command_Injection__wchar_t_listen_socket_execl_43.cpp" 2
# 63 "SARD/000/122/289/CWE78_OS_Command_Injection__wchar_t_listen_socket_execl_43.cpp"
namespace CWE78_OS_Command_Injection__wchar_t_listen_socket_execl_43
{



static void badSource(wchar_t * &data)
{
    {




        int recvResult;
        struct sockaddr_in service;
        wchar_t *replace;
        int listenSocket = -1;
        int acceptSocket = -1;
        size_t dataLen = wcslen(data);
        do
        {
# 91 "SARD/000/122/289/CWE78_OS_Command_Injection__wchar_t_listen_socket_execl_43.cpp"
            listenSocket = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
            if (listenSocket == -1)
            {
                break;
            }
            memset(&service, 0, sizeof(service));
            service.sin_family = AF_INET;
            service.sin_addr.s_addr = INADDR_ANY;
            service.sin_port = htons(27015);
            if (bind(listenSocket, (struct sockaddr*)&service, sizeof(service)) == -1)
            {
                break;
            }
            if (listen(listenSocket, 5) == -1)
            {
                break;
            }
            acceptSocket = accept(listenSocket, NULL, NULL);
            if (acceptSocket == -1)
            {
                break;
            }

            recvResult = recv(acceptSocket, (char *)(data + dataLen), sizeof(wchar_t) * (100 - dataLen - 1), 0);
            if (recvResult == -1 || recvResult == 0)
            {
                break;
            }

            data[dataLen + recvResult / sizeof(wchar_t)] = L'\0';

            replace = wcschr(data, L'\r');
            if (replace)
            {
                *replace = L'\0';
            }
            replace = wcschr(data, L'\n');
            if (replace)
            {
                *replace = L'\0';
            }
        }
        while (0);
        if (listenSocket != -1)
        {
            close(listenSocket);
        }
        if (acceptSocket != -1)
        {
            close(acceptSocket);
        }






    }
}

void bad()
{
    wchar_t * data;
    wchar_t dataBuffer[100] = L"";
    data = dataBuffer;
    badSource(data);


    execl(L"/bin/sh", L"/bin/sh", L"ls", L"-la", data, NULL);
}
# 191 "SARD/000/122/289/CWE78_OS_Command_Injection__wchar_t_listen_socket_execl_43.cpp"
}
