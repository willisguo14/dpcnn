# 1 "SARD/000/122/759/CWE832_Unlock_of_Resource_That_is_Not_Locked__basic_17.c"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 367 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "SARD/000/122/759/CWE832_Unlock_of_Resource_That_is_Not_Locked__basic_17.c" 2
# 49 "SARD/000/122/759/CWE832_Unlock_of_Resource_That_is_Not_Locked__basic_17.c"
static void good1()
{
    int k;
    for(k = 0; k < 1; k++)
    {
        {
            static stdThreadLock goodLock = NULL;
            printLine("Creating lock...");
            if (!stdThreadLockCreate(&goodLock))
            {
                printLine("Could not create lock");
                exit(1);
            }

            printLine("Acquiring lock...");
            stdThreadLockAcquire(goodLock);
            printLine("Releasing lock...");
            stdThreadLockRelease(goodLock);
            printLine("Destroying lock...");
            stdThreadLockDestroy(goodLock);
        }
    }
}

void CWE832_Unlock_of_Resource_That_is_Not_Locked__basic_17_good()
{
    good1();
}
