# 1 "SARD/000/122/759/CWE832_Unlock_of_Resource_That_is_Not_Locked__basic_17.c"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 367 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "SARD/000/122/759/CWE832_Unlock_of_Resource_That_is_Not_Locked__basic_17.c" 2
# 22 "SARD/000/122/759/CWE832_Unlock_of_Resource_That_is_Not_Locked__basic_17.c"
void CWE832_Unlock_of_Resource_That_is_Not_Locked__basic_17_bad()
{
    int j;
    for(j = 0; j < 1; j++)
    {
        {
            static stdThreadLock badLock = NULL;
            printLine("Creating lock...");
            if (!stdThreadLockCreate(&badLock))
            {
                printLine("Could not create lock");
                exit(1);
            }

            printLine("Releasing lock...");
            stdThreadLockRelease(badLock);
            printLine("Destroying lock...");
            stdThreadLockDestroy(badLock);
        }
    }
}
