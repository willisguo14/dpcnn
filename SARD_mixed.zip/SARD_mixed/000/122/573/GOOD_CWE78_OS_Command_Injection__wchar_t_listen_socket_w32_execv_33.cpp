# 1 "SARD/000/122/573/CWE78_OS_Command_Injection__wchar_t_listen_socket_w32_execv_33.cpp"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 380 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "SARD/000/122/573/CWE78_OS_Command_Injection__wchar_t_listen_socket_w32_execv_33.cpp" 2
# 59 "SARD/000/122/573/CWE78_OS_Command_Injection__wchar_t_listen_socket_w32_execv_33.cpp"
namespace CWE78_OS_Command_Injection__wchar_t_listen_socket_w32_execv_33
{
# 165 "SARD/000/122/573/CWE78_OS_Command_Injection__wchar_t_listen_socket_w32_execv_33.cpp"
static void goodG2B()
{
    wchar_t * data;
    wchar_t * &dataRef = data;
    wchar_t dataBuffer[100] = L"";
    data = dataBuffer;

    wcscat(data, L"*.*");
    {
        wchar_t * data = dataRef;
        {
            wchar_t *args[] = {L"/bin/sh", L"ls", L"-la", data, NULL};


            _wexecv(L"/bin/sh", args);
        }
    }
}

void good()
{
    goodG2B();
}



}
