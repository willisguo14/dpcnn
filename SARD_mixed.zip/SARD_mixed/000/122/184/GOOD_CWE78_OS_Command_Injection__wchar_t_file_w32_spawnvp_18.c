# 1 "SARD/000/122/184/CWE78_OS_Command_Injection__wchar_t_file_w32_spawnvp_18.c"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 367 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "SARD/000/122/184/CWE78_OS_Command_Injection__wchar_t_file_w32_spawnvp_18.c" 2
# 88 "SARD/000/122/184/CWE78_OS_Command_Injection__wchar_t_file_w32_spawnvp_18.c"
static void goodG2B()
{
    wchar_t * data;
    wchar_t dataBuffer[100] = L"";
    data = dataBuffer;
    goto source;
source:

    wcscat(data, L"*.*");
    {
        wchar_t *args[] = {L"/bin/sh", L"ls", L"-la", data, NULL};



        _wspawnvp(_P_WAIT, L"sh", args);
    }
}

void CWE78_OS_Command_Injection__wchar_t_file_w32_spawnvp_18_good()
{
    goodG2B();
}
