# 1 "SARD/000/122/355/CWE78_OS_Command_Injection__wchar_t_listen_socket_execlp_81_bad.cpp"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 380 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "SARD/000/122/355/CWE78_OS_Command_Injection__wchar_t_listen_socket_execlp_81_bad.cpp" 2

