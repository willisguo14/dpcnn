# 1 "SARD/000/122/098/CWE78_OS_Command_Injection__wchar_t_file_w32_spawnlp_44.c"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 367 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "SARD/000/122/098/CWE78_OS_Command_Injection__wchar_t_file_w32_spawnlp_44.c" 2
# 46 "SARD/000/122/098/CWE78_OS_Command_Injection__wchar_t_file_w32_spawnlp_44.c"
static void badSink(wchar_t * data)
{



    _wspawnlp(_P_WAIT, L"sh", L"sh", L"ls", L"-la", data, NULL);
}

void CWE78_OS_Command_Injection__wchar_t_file_w32_spawnlp_44_bad()
{
    wchar_t * data;

    void (*funcPtr) (wchar_t *) = badSink;
    wchar_t dataBuffer[100] = L"";
    data = dataBuffer;
    {

        size_t dataLen = wcslen(data);
        FILE * pFile;

        if (100-dataLen > 1)
        {
            pFile = fopen("/tmp/file.txt", "r");
            if (pFile != NULL)
            {

                if (fgetws(data+dataLen, (int)(100-dataLen), pFile) == NULL)
                {
                    printLine("fgetws() failed");

                    data[dataLen] = L'\0';
                }
                fclose(pFile);
            }
        }
    }

    funcPtr(data);
}
