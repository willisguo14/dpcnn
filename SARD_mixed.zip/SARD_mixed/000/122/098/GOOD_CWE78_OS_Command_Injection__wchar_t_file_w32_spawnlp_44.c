# 1 "SARD/000/122/098/CWE78_OS_Command_Injection__wchar_t_file_w32_spawnlp_44.c"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 367 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "SARD/000/122/098/CWE78_OS_Command_Injection__wchar_t_file_w32_spawnlp_44.c" 2
# 91 "SARD/000/122/098/CWE78_OS_Command_Injection__wchar_t_file_w32_spawnlp_44.c"
static void goodG2BSink(wchar_t * data)
{



    _wspawnlp(_P_WAIT, L"sh", L"sh", L"ls", L"-la", data, NULL);
}

static void goodG2B()
{
    wchar_t * data;
    void (*funcPtr) (wchar_t *) = goodG2BSink;
    wchar_t dataBuffer[100] = L"";
    data = dataBuffer;

    wcscat(data, L"*.*");
    funcPtr(data);
}

void CWE78_OS_Command_Injection__wchar_t_file_w32_spawnlp_44_good()
{
    goodG2B();
}
