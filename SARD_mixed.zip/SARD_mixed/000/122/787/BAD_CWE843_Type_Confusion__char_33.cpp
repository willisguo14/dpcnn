# 1 "SARD/000/122/787/CWE843_Type_Confusion__char_33.cpp"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 380 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "SARD/000/122/787/CWE843_Type_Confusion__char_33.cpp" 2
# 19 "SARD/000/122/787/CWE843_Type_Confusion__char_33.cpp"
namespace CWE843_Type_Confusion__char_33
{



void bad()
{
    void * data;
    void * &dataRef = data;

    data = NULL;
    {

        char charBuffer = 'a';
        data = &charBuffer;
    }
    {
        void * data = dataRef;

        printIntLine(*((int*)data));
    }
}
# 72 "SARD/000/122/787/CWE843_Type_Confusion__char_33.cpp"
}
