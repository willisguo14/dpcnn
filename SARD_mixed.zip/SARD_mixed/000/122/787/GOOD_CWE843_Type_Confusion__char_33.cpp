# 1 "SARD/000/122/787/CWE843_Type_Confusion__char_33.cpp"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 380 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "SARD/000/122/787/CWE843_Type_Confusion__char_33.cpp" 2
# 19 "SARD/000/122/787/CWE843_Type_Confusion__char_33.cpp"
namespace CWE843_Type_Confusion__char_33
{
# 47 "SARD/000/122/787/CWE843_Type_Confusion__char_33.cpp"
static void goodG2B()
{
    void * data;
    void * &dataRef = data;

    data = NULL;
    {

        int intBuffer = 8;
        data = &intBuffer;
    }
    {
        void * data = dataRef;

        printIntLine(*((int*)data));
    }
}

void good()
{
    goodG2B();
}



}
