# 1 "SARD/000/122/092/CWE78_OS_Command_Injection__wchar_t_file_w32_spawnlp_32.c"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 367 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "SARD/000/122/092/CWE78_OS_Command_Injection__wchar_t_file_w32_spawnlp_32.c" 2
# 92 "SARD/000/122/092/CWE78_OS_Command_Injection__wchar_t_file_w32_spawnlp_32.c"
static void goodG2B()
{
    wchar_t * data;
    wchar_t * *dataPtr1 = &data;
    wchar_t * *dataPtr2 = &data;
    wchar_t dataBuffer[100] = L"";
    data = dataBuffer;
    {
        wchar_t * data = *dataPtr1;

        wcscat(data, L"*.*");
        *dataPtr1 = data;
    }
    {
        wchar_t * data = *dataPtr2;



        _wspawnlp(_P_WAIT, L"sh", L"sh", L"ls", L"-la", data, NULL);
    }
}

void CWE78_OS_Command_Injection__wchar_t_file_w32_spawnlp_32_good()
{
    goodG2B();
}
