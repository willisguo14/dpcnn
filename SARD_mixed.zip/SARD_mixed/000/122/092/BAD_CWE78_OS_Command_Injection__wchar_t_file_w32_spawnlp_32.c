# 1 "SARD/000/122/092/CWE78_OS_Command_Injection__wchar_t_file_w32_spawnlp_32.c"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 367 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "SARD/000/122/092/CWE78_OS_Command_Injection__wchar_t_file_w32_spawnlp_32.c" 2
# 46 "SARD/000/122/092/CWE78_OS_Command_Injection__wchar_t_file_w32_spawnlp_32.c"
void CWE78_OS_Command_Injection__wchar_t_file_w32_spawnlp_32_bad()
{
    wchar_t * data;
    wchar_t * *dataPtr1 = &data;
    wchar_t * *dataPtr2 = &data;
    wchar_t dataBuffer[100] = L"";
    data = dataBuffer;
    {
        wchar_t * data = *dataPtr1;
        {

            size_t dataLen = wcslen(data);
            FILE * pFile;

            if (100-dataLen > 1)
            {
                pFile = fopen("/tmp/file.txt", "r");
                if (pFile != NULL)
                {

                    if (fgetws(data+dataLen, (int)(100-dataLen), pFile) == NULL)
                    {
                        printLine("fgetws() failed");

                        data[dataLen] = L'\0';
                    }
                    fclose(pFile);
                }
            }
        }
        *dataPtr1 = data;
    }
    {
        wchar_t * data = *dataPtr2;



        _wspawnlp(_P_WAIT, L"sh", L"sh", L"ls", L"-la", data, NULL);
    }
}
