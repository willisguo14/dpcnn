# 1 "SARD/000/122/842/CWE843_Type_Confusion__short_72b.cpp"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 380 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "SARD/000/122/842/CWE843_Type_Confusion__short_72b.cpp" 2
# 20 "SARD/000/122/842/CWE843_Type_Confusion__short_72b.cpp"
using namespace std;

namespace CWE843_Type_Confusion__short_72
{



void badSink(vector<void *> dataVector)
{

    void * data = dataVector[2];

    printIntLine(*((int*)data));
}
# 49 "SARD/000/122/842/CWE843_Type_Confusion__short_72b.cpp"
}
