# 1 "SARD/000/122/323/CWE78_OS_Command_Injection__wchar_t_listen_socket_execlp_13.c"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 367 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "SARD/000/122/323/CWE78_OS_Command_Injection__wchar_t_listen_socket_execlp_13.c" 2
# 163 "SARD/000/122/323/CWE78_OS_Command_Injection__wchar_t_listen_socket_execlp_13.c"
static void goodG2B1()
{
    wchar_t * data;
    wchar_t dataBuffer[100] = L"";
    data = dataBuffer;
    if(GLOBAL_CONST_FIVE!=5)
    {

        printLine("Benign, fixed string");
    }
    else
    {

        wcscat(data, L"*.*");
    }



    execlp(L"sh", L"sh", L"ls", L"-la", data, NULL);
}


static void goodG2B2()
{
    wchar_t * data;
    wchar_t dataBuffer[100] = L"";
    data = dataBuffer;
    if(GLOBAL_CONST_FIVE==5)
    {

        wcscat(data, L"*.*");
    }



    execlp(L"sh", L"sh", L"ls", L"-la", data, NULL);
}

void CWE78_OS_Command_Injection__wchar_t_listen_socket_execlp_13_good()
{
    goodG2B1();
    goodG2B2();
}
