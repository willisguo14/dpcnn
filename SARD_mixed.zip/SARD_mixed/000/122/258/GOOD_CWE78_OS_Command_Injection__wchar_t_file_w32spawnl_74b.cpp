# 1 "SARD/000/122/258/CWE78_OS_Command_Injection__wchar_t_file_w32spawnl_74b.cpp"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 380 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "SARD/000/122/258/CWE78_OS_Command_Injection__wchar_t_file_w32spawnl_74b.cpp" 2
# 39 "SARD/000/122/258/CWE78_OS_Command_Injection__wchar_t_file_w32spawnl_74b.cpp"
using namespace std;

namespace CWE78_OS_Command_Injection__wchar_t_file_w32spawnl_74
{
# 60 "SARD/000/122/258/CWE78_OS_Command_Injection__wchar_t_file_w32spawnl_74b.cpp"
void goodG2BSink(map<int, wchar_t *> dataMap)
{
    wchar_t * data = dataMap[2];


    _wspawnl(_P_WAIT, L"/bin/sh", L"/bin/sh", L"ls", L"-la", data, NULL);
}



}
