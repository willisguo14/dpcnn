# 1 "SARD/000/122/623/CWE78_OS_Command_Injection__wchar_t_listen_socket_w32_spawnlp_41.c"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 367 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "SARD/000/122/623/CWE78_OS_Command_Injection__wchar_t_listen_socket_w32_spawnlp_41.c" 2
# 60 "SARD/000/122/623/CWE78_OS_Command_Injection__wchar_t_listen_socket_w32_spawnlp_41.c"
void CWE78_OS_Command_Injection__wchar_t_listen_socket_w32_spawnlp_41_badSink(wchar_t * data)
{



    _wspawnlp(_P_WAIT, L"sh", L"sh", L"ls", L"-la", data, NULL);
}

void CWE78_OS_Command_Injection__wchar_t_listen_socket_w32_spawnlp_41_bad()
{
    wchar_t * data;
    wchar_t dataBuffer[100] = L"";
    data = dataBuffer;
    {




        int recvResult;
        struct sockaddr_in service;
        wchar_t *replace;
        int listenSocket = -1;
        int acceptSocket = -1;
        size_t dataLen = wcslen(data);
        do
        {
# 94 "SARD/000/122/623/CWE78_OS_Command_Injection__wchar_t_listen_socket_w32_spawnlp_41.c"
            listenSocket = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
            if (listenSocket == -1)
            {
                break;
            }
            memset(&service, 0, sizeof(service));
            service.sin_family = AF_INET;
            service.sin_addr.s_addr = INADDR_ANY;
            service.sin_port = htons(27015);
            if (bind(listenSocket, (struct sockaddr*)&service, sizeof(service)) == -1)
            {
                break;
            }
            if (listen(listenSocket, 5) == -1)
            {
                break;
            }
            acceptSocket = accept(listenSocket, NULL, NULL);
            if (acceptSocket == -1)
            {
                break;
            }

            recvResult = recv(acceptSocket, (char *)(data + dataLen), sizeof(wchar_t) * (100 - dataLen - 1), 0);
            if (recvResult == -1 || recvResult == 0)
            {
                break;
            }

            data[dataLen + recvResult / sizeof(wchar_t)] = L'\0';

            replace = wcschr(data, L'\r');
            if (replace)
            {
                *replace = L'\0';
            }
            replace = wcschr(data, L'\n');
            if (replace)
            {
                *replace = L'\0';
            }
        }
        while (0);
        if (listenSocket != -1)
        {
            close(listenSocket);
        }
        if (acceptSocket != -1)
        {
            close(acceptSocket);
        }






    }
    CWE78_OS_Command_Injection__wchar_t_listen_socket_w32_spawnlp_41_badSink(data);
}
