# 1 "SARD/000/122/623/CWE78_OS_Command_Injection__wchar_t_listen_socket_w32_spawnlp_41.c"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 367 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "SARD/000/122/623/CWE78_OS_Command_Injection__wchar_t_listen_socket_w32_spawnlp_41.c" 2
# 159 "SARD/000/122/623/CWE78_OS_Command_Injection__wchar_t_listen_socket_w32_spawnlp_41.c"
void CWE78_OS_Command_Injection__wchar_t_listen_socket_w32_spawnlp_41_goodG2BSink(wchar_t * data)
{



    _wspawnlp(_P_WAIT, L"sh", L"sh", L"ls", L"-la", data, NULL);
}


static void goodG2B()
{
    wchar_t * data;
    wchar_t dataBuffer[100] = L"";
    data = dataBuffer;

    wcscat(data, L"*.*");
    CWE78_OS_Command_Injection__wchar_t_listen_socket_w32_spawnlp_41_goodG2BSink(data);
}

void CWE78_OS_Command_Injection__wchar_t_listen_socket_w32_spawnlp_41_good()
{
    goodG2B();
}
