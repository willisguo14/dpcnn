# 1 "SARD/000/122/345/CWE78_OS_Command_Injection__wchar_t_listen_socket_execlp_62a.cpp"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 380 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "SARD/000/122/345/CWE78_OS_Command_Injection__wchar_t_listen_socket_execlp_62a.cpp" 2
# 43 "SARD/000/122/345/CWE78_OS_Command_Injection__wchar_t_listen_socket_execlp_62a.cpp"
namespace CWE78_OS_Command_Injection__wchar_t_listen_socket_execlp_62
{




void badSource(wchar_t * &data);

void bad()
{
    wchar_t * data;
    wchar_t dataBuffer[100] = L"";
    data = dataBuffer;
    badSource(data);



    execlp(L"sh", L"sh", L"ls", L"-la", data, NULL);
}
# 89 "SARD/000/122/345/CWE78_OS_Command_Injection__wchar_t_listen_socket_execlp_62a.cpp"
}
