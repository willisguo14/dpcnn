# 1 "SARD/000/122/199/CWE78_OS_Command_Injection__wchar_t_file_w32_spawnvp_54e.c"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 367 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "SARD/000/122/199/CWE78_OS_Command_Injection__wchar_t_file_w32_spawnvp_54e.c" 2
# 48 "SARD/000/122/199/CWE78_OS_Command_Injection__wchar_t_file_w32_spawnvp_54e.c"
void CWE78_OS_Command_Injection__wchar_t_file_w32_spawnvp_54e_badSink(wchar_t * data)
{
    {
        wchar_t *args[] = {L"/bin/sh", L"ls", L"-la", data, NULL};



        _wspawnvp(_P_WAIT, L"sh", args);
    }
}
