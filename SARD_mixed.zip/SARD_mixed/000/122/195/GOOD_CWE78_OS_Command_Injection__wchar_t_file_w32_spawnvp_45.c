# 1 "SARD/000/122/195/CWE78_OS_Command_Injection__wchar_t_file_w32_spawnvp_45.c"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 367 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "SARD/000/122/195/CWE78_OS_Command_Injection__wchar_t_file_w32_spawnvp_45.c" 2
# 44 "SARD/000/122/195/CWE78_OS_Command_Injection__wchar_t_file_w32_spawnvp_45.c"
static wchar_t * CWE78_OS_Command_Injection__wchar_t_file_w32_spawnvp_45_badData;
static wchar_t * CWE78_OS_Command_Injection__wchar_t_file_w32_spawnvp_45_goodG2BData;
# 96 "SARD/000/122/195/CWE78_OS_Command_Injection__wchar_t_file_w32_spawnvp_45.c"
static void goodG2BSink()
{
    wchar_t * data = CWE78_OS_Command_Injection__wchar_t_file_w32_spawnvp_45_goodG2BData;
    {
        wchar_t *args[] = {L"/bin/sh", L"ls", L"-la", data, NULL};



        _wspawnvp(_P_WAIT, L"sh", args);
    }
}

static void goodG2B()
{
    wchar_t * data;
    wchar_t dataBuffer[100] = L"";
    data = dataBuffer;

    wcscat(data, L"*.*");
    CWE78_OS_Command_Injection__wchar_t_file_w32_spawnvp_45_goodG2BData = data;
    goodG2BSink();
}

void CWE78_OS_Command_Injection__wchar_t_file_w32_spawnvp_45_good()
{
    goodG2B();
}
