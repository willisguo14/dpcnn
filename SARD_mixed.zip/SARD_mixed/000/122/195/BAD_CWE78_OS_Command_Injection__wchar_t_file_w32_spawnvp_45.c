# 1 "SARD/000/122/195/CWE78_OS_Command_Injection__wchar_t_file_w32_spawnvp_45.c"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 367 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "SARD/000/122/195/CWE78_OS_Command_Injection__wchar_t_file_w32_spawnvp_45.c" 2
# 44 "SARD/000/122/195/CWE78_OS_Command_Injection__wchar_t_file_w32_spawnvp_45.c"
static wchar_t * CWE78_OS_Command_Injection__wchar_t_file_w32_spawnvp_45_badData;
static wchar_t * CWE78_OS_Command_Injection__wchar_t_file_w32_spawnvp_45_goodG2BData;



static void badSink()
{
    wchar_t * data = CWE78_OS_Command_Injection__wchar_t_file_w32_spawnvp_45_badData;
    {
        wchar_t *args[] = {L"/bin/sh", L"ls", L"-la", data, NULL};



        _wspawnvp(_P_WAIT, L"sh", args);
    }
}

void CWE78_OS_Command_Injection__wchar_t_file_w32_spawnvp_45_bad()
{
    wchar_t * data;
    wchar_t dataBuffer[100] = L"";
    data = dataBuffer;
    {

        size_t dataLen = wcslen(data);
        FILE * pFile;

        if (100-dataLen > 1)
        {
            pFile = fopen("/tmp/file.txt", "r");
            if (pFile != NULL)
            {

                if (fgetws(data+dataLen, (int)(100-dataLen), pFile) == NULL)
                {
                    printLine("fgetws() failed");

                    data[dataLen] = L'\0';
                }
                fclose(pFile);
            }
        }
    }
    CWE78_OS_Command_Injection__wchar_t_file_w32_spawnvp_45_badData = data;
    badSink();
}
