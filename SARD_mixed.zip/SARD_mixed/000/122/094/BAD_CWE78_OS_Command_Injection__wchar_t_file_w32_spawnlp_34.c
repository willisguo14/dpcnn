# 1 "SARD/000/122/094/CWE78_OS_Command_Injection__wchar_t_file_w32_spawnlp_34.c"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 367 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "SARD/000/122/094/CWE78_OS_Command_Injection__wchar_t_file_w32_spawnlp_34.c" 2
# 44 "SARD/000/122/094/CWE78_OS_Command_Injection__wchar_t_file_w32_spawnlp_34.c"
typedef union
{
    wchar_t * unionFirst;
    wchar_t * unionSecond;
} CWE78_OS_Command_Injection__wchar_t_file_w32_spawnlp_34_unionType;



void CWE78_OS_Command_Injection__wchar_t_file_w32_spawnlp_34_bad()
{
    wchar_t * data;
    CWE78_OS_Command_Injection__wchar_t_file_w32_spawnlp_34_unionType myUnion;
    wchar_t dataBuffer[100] = L"";
    data = dataBuffer;
    {

        size_t dataLen = wcslen(data);
        FILE * pFile;

        if (100-dataLen > 1)
        {
            pFile = fopen("/tmp/file.txt", "r");
            if (pFile != NULL)
            {

                if (fgetws(data+dataLen, (int)(100-dataLen), pFile) == NULL)
                {
                    printLine("fgetws() failed");

                    data[dataLen] = L'\0';
                }
                fclose(pFile);
            }
        }
    }
    myUnion.unionFirst = data;
    {
        wchar_t * data = myUnion.unionSecond;



        _wspawnlp(_P_WAIT, L"sh", L"sh", L"ls", L"-la", data, NULL);
    }
}
