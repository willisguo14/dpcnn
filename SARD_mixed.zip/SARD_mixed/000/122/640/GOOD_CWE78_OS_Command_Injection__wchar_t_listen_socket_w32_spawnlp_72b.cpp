# 1 "SARD/000/122/640/CWE78_OS_Command_Injection__wchar_t_listen_socket_w32_spawnlp_72b.cpp"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 380 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "SARD/000/122/640/CWE78_OS_Command_Injection__wchar_t_listen_socket_w32_spawnlp_72b.cpp" 2
# 39 "SARD/000/122/640/CWE78_OS_Command_Injection__wchar_t_listen_socket_w32_spawnlp_72b.cpp"
using namespace std;

namespace CWE78_OS_Command_Injection__wchar_t_listen_socket_w32_spawnlp_72
{
# 61 "SARD/000/122/640/CWE78_OS_Command_Injection__wchar_t_listen_socket_w32_spawnlp_72b.cpp"
void goodG2BSink(vector<wchar_t *> dataVector)
{
    wchar_t * data = dataVector[2];



    _wspawnlp(_P_WAIT, L"sh", L"sh", L"ls", L"-la", data, NULL);
}



}
