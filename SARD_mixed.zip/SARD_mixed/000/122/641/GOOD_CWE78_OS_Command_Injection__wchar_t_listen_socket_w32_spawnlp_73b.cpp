# 1 "SARD/000/122/641/CWE78_OS_Command_Injection__wchar_t_listen_socket_w32_spawnlp_73b.cpp"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 380 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "SARD/000/122/641/CWE78_OS_Command_Injection__wchar_t_listen_socket_w32_spawnlp_73b.cpp" 2
# 39 "SARD/000/122/641/CWE78_OS_Command_Injection__wchar_t_listen_socket_w32_spawnlp_73b.cpp"
using namespace std;

namespace CWE78_OS_Command_Injection__wchar_t_listen_socket_w32_spawnlp_73
{
# 61 "SARD/000/122/641/CWE78_OS_Command_Injection__wchar_t_listen_socket_w32_spawnlp_73b.cpp"
void goodG2BSink(list<wchar_t *> dataList)
{
    wchar_t * data = dataList.back();



    _wspawnlp(_P_WAIT, L"sh", L"sh", L"ls", L"-la", data, NULL);
}



}
