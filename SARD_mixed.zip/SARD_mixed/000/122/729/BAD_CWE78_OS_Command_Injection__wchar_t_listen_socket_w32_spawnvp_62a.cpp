# 1 "SARD/000/122/729/CWE78_OS_Command_Injection__wchar_t_listen_socket_w32_spawnvp_62a.cpp"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 380 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "SARD/000/122/729/CWE78_OS_Command_Injection__wchar_t_listen_socket_w32_spawnvp_62a.cpp" 2
# 38 "SARD/000/122/729/CWE78_OS_Command_Injection__wchar_t_listen_socket_w32_spawnvp_62a.cpp"
namespace CWE78_OS_Command_Injection__wchar_t_listen_socket_w32_spawnvp_62
{




void badSource(wchar_t * &data);

void bad()
{
    wchar_t * data;
    wchar_t dataBuffer[100] = L"";
    data = dataBuffer;
    badSource(data);
    {
        wchar_t *args[] = {L"/bin/sh", L"ls", L"-la", data, NULL};



        _wspawnvp(_P_WAIT, L"sh", args);
    }
}
# 90 "SARD/000/122/729/CWE78_OS_Command_Injection__wchar_t_listen_socket_w32_spawnvp_62a.cpp"
}
