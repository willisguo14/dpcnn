# 1 "SARD/000/122/017/CWE78_OS_Command_Injection__wchar_t_file_w32_execv_73b.cpp"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 380 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "SARD/000/122/017/CWE78_OS_Command_Injection__wchar_t_file_w32_execv_73b.cpp" 2
# 40 "SARD/000/122/017/CWE78_OS_Command_Injection__wchar_t_file_w32_execv_73b.cpp"
using namespace std;

namespace CWE78_OS_Command_Injection__wchar_t_file_w32_execv_73
{



void badSink(list<wchar_t *> dataList)
{

    wchar_t * data = dataList.back();
    {
        wchar_t *args[] = {L"/bin/sh", L"ls", L"-la", data, NULL};


        _wexecv(L"/bin/sh", args);
    }
}
# 77 "SARD/000/122/017/CWE78_OS_Command_Injection__wchar_t_file_w32_execv_73b.cpp"
}
