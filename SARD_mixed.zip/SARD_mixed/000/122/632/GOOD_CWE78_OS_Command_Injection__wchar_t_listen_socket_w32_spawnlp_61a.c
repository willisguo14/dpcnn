# 1 "SARD/000/122/632/CWE78_OS_Command_Injection__wchar_t_listen_socket_w32_spawnlp_61a.c"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 367 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "SARD/000/122/632/CWE78_OS_Command_Injection__wchar_t_listen_socket_w32_spawnlp_61a.c" 2
# 80 "SARD/000/122/632/CWE78_OS_Command_Injection__wchar_t_listen_socket_w32_spawnlp_61a.c"
wchar_t * CWE78_OS_Command_Injection__wchar_t_listen_socket_w32_spawnlp_61b_goodG2BSource(wchar_t * data);

static void goodG2B()
{
    wchar_t * data;
    wchar_t dataBuffer[100] = L"";
    data = dataBuffer;
    data = CWE78_OS_Command_Injection__wchar_t_listen_socket_w32_spawnlp_61b_goodG2BSource(data);



    _wspawnlp(_P_WAIT, L"sh", L"sh", L"ls", L"-la", data, NULL);
}

void CWE78_OS_Command_Injection__wchar_t_listen_socket_w32_spawnlp_61_good()
{
    goodG2B();
}
