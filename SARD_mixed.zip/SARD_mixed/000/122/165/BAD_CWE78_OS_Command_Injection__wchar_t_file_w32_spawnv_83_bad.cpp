# 1 "SARD/000/122/165/CWE78_OS_Command_Injection__wchar_t_file_w32_spawnv_83_bad.cpp"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 380 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "SARD/000/122/165/CWE78_OS_Command_Injection__wchar_t_file_w32_spawnv_83_bad.cpp" 2
# 29 "SARD/000/122/165/CWE78_OS_Command_Injection__wchar_t_file_w32_spawnv_83_bad.cpp"
namespace CWE78_OS_Command_Injection__wchar_t_file_w32_spawnv_83
{
CWE78_OS_Command_Injection__wchar_t_file_w32_spawnv_83_bad::CWE78_OS_Command_Injection__wchar_t_file_w32_spawnv_83_bad(wchar_t * dataCopy)
{
    data = dataCopy;
    {

        size_t dataLen = wcslen(data);
        FILE * pFile;

        if (100-dataLen > 1)
        {
            pFile = fopen("/tmp/file.txt", "r");
            if (pFile != NULL)
            {

                if (fgetws(data+dataLen, (int)(100-dataLen), pFile) == NULL)
                {
                    printLine("fgetws() failed");

                    data[dataLen] = L'\0';
                }
                fclose(pFile);
            }
        }
    }
}

CWE78_OS_Command_Injection__wchar_t_file_w32_spawnv_83_bad::~CWE78_OS_Command_Injection__wchar_t_file_w32_spawnv_83_bad()
{
    {
        wchar_t *args[] = {COMMAND_INT_PATH, COMMAND_ARG1, COMMAND_ARG2, COMMAND_ARG3, NULL};


        _wspawnv(_P_WAIT, COMMAND_INT_PATH, args);
    }
}
}
