# 1 "SARD/000/122/356/CWE78_OS_Command_Injection__wchar_t_listen_socket_execlp_82_bad.cpp"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 380 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "SARD/000/122/356/CWE78_OS_Command_Injection__wchar_t_listen_socket_execlp_82_bad.cpp" 2
# 28 "SARD/000/122/356/CWE78_OS_Command_Injection__wchar_t_listen_socket_execlp_82_bad.cpp"
namespace CWE78_OS_Command_Injection__wchar_t_listen_socket_execlp_82
{

void CWE78_OS_Command_Injection__wchar_t_listen_socket_execlp_82_bad::action(wchar_t * data)
{



    execlp(COMMAND_INT, COMMAND_INT, COMMAND_ARG1, COMMAND_ARG2, COMMAND_ARG3, NULL);
}

}
