# 1 "SARD/000/122/237/CWE78_OS_Command_Injection__wchar_t_file_w32spawnl_33.cpp"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 380 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "SARD/000/122/237/CWE78_OS_Command_Injection__wchar_t_file_w32spawnl_33.cpp" 2
# 44 "SARD/000/122/237/CWE78_OS_Command_Injection__wchar_t_file_w32spawnl_33.cpp"
namespace CWE78_OS_Command_Injection__wchar_t_file_w32spawnl_33
{



void bad()
{
    wchar_t * data;
    wchar_t * &dataRef = data;
    wchar_t dataBuffer[100] = L"";
    data = dataBuffer;
    {

        size_t dataLen = wcslen(data);
        FILE * pFile;

        if (100-dataLen > 1)
        {
            pFile = fopen("/tmp/file.txt", "r");
            if (pFile != NULL)
            {

                if (fgetws(data+dataLen, (int)(100-dataLen), pFile) == NULL)
                {
                    printLine("fgetws() failed");

                    data[dataLen] = L'\0';
                }
                fclose(pFile);
            }
        }
    }
    {
        wchar_t * data = dataRef;


        _wspawnl(_P_WAIT, L"/bin/sh", L"/bin/sh", L"ls", L"-la", data, NULL);
    }
}
# 112 "SARD/000/122/237/CWE78_OS_Command_Injection__wchar_t_file_w32spawnl_33.cpp"
}
