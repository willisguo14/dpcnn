# 1 "SARD/000/122/305/CWE78_OS_Command_Injection__wchar_t_listen_socket_execl_73b.cpp"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 380 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "SARD/000/122/305/CWE78_OS_Command_Injection__wchar_t_listen_socket_execl_73b.cpp" 2
# 44 "SARD/000/122/305/CWE78_OS_Command_Injection__wchar_t_listen_socket_execl_73b.cpp"
using namespace std;

namespace CWE78_OS_Command_Injection__wchar_t_listen_socket_execl_73
{
# 65 "SARD/000/122/305/CWE78_OS_Command_Injection__wchar_t_listen_socket_execl_73b.cpp"
void goodG2BSink(list<wchar_t *> dataList)
{
    wchar_t * data = dataList.back();


    execl(L"/bin/sh", L"/bin/sh", L"ls", L"-la", data, NULL);
}



}
